#!/usr/bin/env python3
"""Reproduce response-surface analysis without changing the input workbook."""
import argparse, base64, hashlib, html, io, json, math, os, shutil, sys, zipfile
from pathlib import Path
os.environ.setdefault('MPLCONFIGDIR', '/workspace/scratch/response_surface/mplconfig')
import numpy as np
import pandas as pd
from scipy import stats, optimize
import statsmodels.api as sm
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib import font_manager
from openpyxl import load_workbook
from openpyxl.styles import Font, PatternFill, Alignment
from openpyxl.utils import get_column_letter

LABELS = {'F':'氟萃取率/%','P':'磷损失率/%','beta':'氟选择性系数β','log_beta':'ln(β)'}
MODEL_LABELS={'linear':'线性','2FI':'双因素交互','quadratic':'完整二次'}
TERMS=['Intercept','A','B','C','AB','AC','BC','A²','B²','C²']

def matrix(x, kind='quadratic'):
    x=np.atleast_2d(x); a,b,c=x.T
    z=np.column_stack([np.ones(len(x)),a,b,c,a*b,a*c,b*c,a*a,b*b,c*c])
    n={'linear':4,'2FI':7,'quadratic':10}[kind]
    return pd.DataFrame(z[:,:n],columns=TERMS[:n])

def read_data(source, version='Sheet1'):
    w=load_workbook(source,data_only=True); s=w['Sheet1']; s2=w['Sheet2']
    rows=[]
    for r in range(2,19):
        d=dict(zip(['Std','Run','Temperature','Ratio','Initial_F','V_after','F_before','P_before','F_after','P_after'],
                   [s.cell(r,c).value for c in [1,2,3,4,5,6,10,11,12,13]]))
        d['Excel_row']=r
        if version=='Sheet2':
            for k,c in [('V_after',12),('F_before',13),('P_before',14),('F_after',6),('P_after',8)]:
                d[k]=s2.cell(r+9,c).value
        d['A']=(d['Temperature']-85)/10;d['B']=(d['Ratio']-1)/.333;d['C']=(d['Initial_F']-1)/.2
        d['F']=100*(1-d['V_after']*d['F_after']/(50*d['F_before']))
        d['P']=100*(1-d['V_after']*d['P_after']/(50*d['P_before']))
        d['beta']=((50*d['F_before']-d['V_after']*d['F_after'])/d['F_after'])/((50*d['P_before']-d['V_after']*d['P_after'])/d['P_after'])
        d['log_beta']=np.log(d['beta'])
        rows.append(d)
    return pd.DataFrame(rows)

def fit(data, response, kind):
    y=data[response].to_numpy(); x=matrix(data[['A','B','C']],kind); model=sm.OLS(y,x).fit()
    n=len(y); p=x.shape[1]; infl=model.get_influence(); h=infl.hat_matrix_diag
    pe=sum(float(((g[response]-g[response].mean())**2).sum()) for _,g in data.groupby(['A','B','C']))
    pe_df=n-len(data.groupby(['A','B','C'])); lof_df=int(model.df_resid)-pe_df
    lof_ss=max(0,float(model.ssr)-pe); lof_f=(lof_ss/lof_df)/(pe/pe_df)
    press=float(np.sum((model.resid/(1-h))**2)); pred_r2=1-press/model.centered_tss
    s=float(np.sqrt(model.mse_resid))
    # Standard DOE adequate precision: fitted response range / mean prediction SE.
    ap=float(np.ptp(model.fittedvalues)/np.sqrt(p*model.mse_resid/n))
    info={'response':response,'model':kind,'n':n,'parameters':p,'R2':float(model.rsquared),
          'adj_R2':float(model.rsquared_adj),'pred_R2_LOO':float(pred_r2),'PRESS':press,'RMSE':s,
          'CV_percent':100*s/float(np.mean(y)), 'adequate_precision':ap,
          'model_F':float(model.fvalue),'model_p':float(model.f_pvalue),
          'SSE':float(model.ssr),'SST':float(model.centered_tss),'pure_error_SS':pe,
          'pure_error_df':pe_df,'lack_of_fit_SS':lof_ss,'lack_of_fit_df':lof_df,
          'lack_of_fit_F':lof_f,'lack_of_fit_p':float(stats.f.sf(lof_f,lof_df,pe_df)),
          'df_resid':int(model.df_resid),'Shapiro_p':float(stats.shapiro(model.resid).pvalue)}
    return model,info

def model_anova(m,info):
    rss=float(m.ssr); rows=[]
    rows.append({'来源':'模型','SS':float(m.centered_tss-rss),'df':int(m.df_model),'MS':float((m.centered_tss-rss)/m.df_model),'F':float(m.fvalue),'p':float(m.f_pvalue)})
    rows.append({'来源':'残差','SS':rss,'df':int(m.df_resid),'MS':float(m.mse_resid),'F':None,'p':None})
    rows.append({'来源':'失拟','SS':info['lack_of_fit_SS'],'df':info['lack_of_fit_df'],'MS':info['lack_of_fit_SS']/info['lack_of_fit_df'],'F':info['lack_of_fit_F'],'p':info['lack_of_fit_p']})
    rows.append({'来源':'纯误差','SS':info['pure_error_SS'],'df':info['pure_error_df'],'MS':info['pure_error_SS']/info['pure_error_df'],'F':None,'p':None})
    rows.append({'来源':'校正总和','SS':float(m.centered_tss),'df':int(m.nobs-1),'MS':None,'F':None,'p':None})
    return rows

def partial_terms(m):
    out=[]; x=m.model.exog; y=m.model.endog
    for j,name in enumerate(m.model.exog_names):
        if j==0: continue
        reduced=sm.OLS(y,np.delete(x,j,axis=1)).fit(); ss=max(0,float(reduced.ssr-m.ssr)); f=ss/m.mse_resid
        out.append({'项':name,'偏SS':ss,'df':1,'MS':ss,'F':f,'p':float(stats.f.sf(f,1,m.df_resid))})
    return out

def prediction(m,x,kind):
    r=m.get_prediction(matrix(x,kind)).summary_frame(alpha=.05).iloc[0]
    return {k:float(v) for k,v in r.items()}

def table(df, digits=4):
    return df.to_html(index=False,border=0,float_format=lambda x:f'{x:.{digits}g}',escape=True,na_rep='—')

def main():
    parser=argparse.ArgumentParser();parser.add_argument('source');parser.add_argument('--output',required=True)
    args=parser.parse_args();source=Path(args.source);out=Path(args.output);out.mkdir(parents=True,exist_ok=True)
    plots=out/'图表';plots.mkdir(exist_ok=True)
    original_hash=hashlib.sha256(source.read_bytes()).hexdigest()
    font_path='/usr/share/fonts/opentype/noto/NotoSansCJK-Regular.ttc'
    if Path(font_path).exists():
        font_manager.fontManager.addfont(font_path)
        plt.rcParams['font.family']=font_manager.FontProperties(fname=font_path).get_name()
    plt.rcParams.update({'axes.unicode_minus':False,'font.size':10,'axes.spines.top':False,'axes.spines.right':False,'savefig.dpi':180})
    data=read_data(source); alt=read_data(source,'Sheet2');x=data[['A','B','C']].to_numpy()
    assert len(data)==17 and len(np.unique(x,axis=0))==13
    assert np.linalg.matrix_rank(matrix(x))==10
    assert np.all((data[['F','P']]>0)&(data[['F','P']]<100))
    models={}; summaries=[]; anovas=[]; coeffs=[]; partial=[]; diagnostics=[]; steps=[]
    for response in LABELS:
        for kind in MODEL_LABELS:
            if response=='log_beta' and kind!='quadratic':continue
            m,info=fit(data,response,kind);models[(response,kind)]=(m,info);summaries.append(info)
            if kind=='quadratic' or (response=='P' and kind=='linear'):
                for row in model_anova(m,info):anovas.append({'响应':LABELS[response],'模型':MODEL_LABELS[kind],**row})
                for row in partial_terms(m):partial.append({'响应':LABELS[response],'模型':MODEL_LABELS[kind],**row})
                ci=m.conf_int()
                for term in m.params.index:
                    coeffs.append({'响应':LABELS[response],'模型':MODEL_LABELS[kind],'项':term,'系数':m.params[term],'标准误':m.bse[term],'t':m.tvalues[term],'p':m.pvalues[term],'CI95下限':ci.loc[term,0],'CI95上限':ci.loc[term,1]})
                infl=m.get_influence();bonf=stats.t.ppf(1-.05/(2*len(data)),int(m.df_resid)-1)
                for j,row in data.iterrows():
                    diagnostics.append({'响应':LABELS[response],'模型':MODEL_LABELS[kind],'运行号':int(row.Run),'实测':row[response],
                        '拟合':float(m.fittedvalues.iloc[j]),'残差':float(m.resid.iloc[j]),'外学生化残差':infl.resid_studentized_external[j],
                        '杠杆值':infl.hat_matrix_diag[j],'Cook_D':infl.cooks_distance[0][j],
                        'LOO预测':float(row[response]-m.resid.iloc[j]/(1-infl.hat_matrix_diag[j])),
                        'Bonferroni临界值':bonf,'Bonferroni校正p':min(1.,float(2*len(data)*stats.t.sf(abs(infl.resid_studentized_external[j]),int(m.df_resid)-1))),
                        'Bonferroni异常':bool(abs(infl.resid_studentized_external[j])>bonf)})
        if response!='log_beta':
            for low,high in [('linear','2FI'),('2FI','quadratic')]:
                ml,il=models[(response,low)];mh,ih=models[(response,high)];nd=ih['parameters']-il['parameters']
                ss=float(ml.ssr-mh.ssr);ff=ss/nd/mh.mse_resid
                steps.append({'响应':LABELS[response],'新增部分':f'{MODEL_LABELS[low]} → {MODEL_LABELS[high]}','SS':ss,'df':nd,'F':ff,'p':float(stats.f.sf(ff,nd,mh.df_resid))})
    summary=pd.DataFrame(summaries)
    comparison=summary.copy();comparison['response']=comparison['response'].map(LABELS);comparison['model']=comparison['model'].map(MODEL_LABELS)
    # Independent direct refitting verifies analytic PRESS (not merely training residuals).
    for response,kind in [('F','quadratic'),('P','linear'),('beta','quadratic')]:
        m,info=models[(response,kind)]; z=matrix(x,kind).to_numpy(); y=data[response].to_numpy(); loo=[]
        for j in range(len(y)):
            mask=np.arange(len(y))!=j; b=np.linalg.lstsq(z[mask],y[mask],rcond=None)[0];loo.append(y[j]-z[j]@b)
        assert np.isclose(np.sum(np.square(loo)),info['PRESS'],rtol=1e-9)
    # Secondary source is audited, never substituted into the user-confirmed primary data.
    diff=[]
    for i in range(len(data)):
        for col in ['F_after','P_after','F','P','beta']:
            if not np.isclose(data.iloc[i][col],alt.iloc[i][col],rtol=1e-12,atol=1e-12):
                diff.append({'运行号':int(data.iloc[i].Run),'Sheet1行':int(data.iloc[i].Excel_row),'Sheet2行':int(data.iloc[i].Excel_row+9),'字段':col,'Sheet1':data.iloc[i][col],'Sheet2':alt.iloc[i][col],'Sheet2减Sheet1':alt.iloc[i][col]-data.iloc[i][col]})
    sensitivity=[]
    for response,kind in [('F','quadratic'),('P','quadratic'),('P','linear'),('beta','quadratic')]:
        _,ii=fit(alt,response,kind);_,ip=models[(response,kind)]
        for version,item in [('Sheet1（采用）',ip),('Sheet2（仅对照）',ii)]:
            sensitivity.append({'数据版本':version,'响应':LABELS[response],'模型':MODEL_LABELS[kind],**{k:item[k] for k in ['R2','adj_R2','pred_R2_LOO','model_p','lack_of_fit_p']}})
    mf,fi=models[('F','quadratic')];mp,pi=models[('P','linear')]
    fmin,fmax=data.F.min(),data.F.max();pmin,pmax=data.P.min(),data.P.max()
    bf=mf.params.to_numpy();bp=mp.params.to_numpy()
    def pred_fast(xx):
        xx=np.atleast_2d(xx);z=matrix(xx).to_numpy();return z@bf,z[:,:4]@bp
    def desirability(xx):
        ff,pp=pred_fast(xx)
        return np.sqrt(np.clip((ff-fmin)/(fmax-fmin),0,1)*np.clip((pmax-pp)/(pmax-pmin),0,1))
    axis=np.linspace(-1,1,41);grid=np.array(np.meshgrid(axis,axis,axis,indexing='ij')).reshape(3,-1).T
    grid=grid[np.abs(grid).sum(axis=1)<=2+1e-12];dg=desirability(grid);best_idx=np.argsort(dg)[-12:]
    starts=np.vstack([grid[best_idx],x,np.zeros((1,3))]);solutions=[]
    for start in starts:
        result=optimize.minimize(lambda v:-float(desirability(v)[0]),start,method='SLSQP',bounds=[(-1,1)]*3,
              constraints=[{'type':'ineq','fun':lambda v:2-np.abs(v).sum()}],options={'ftol':1e-12,'maxiter':500})
        if result.success and np.abs(result.x).sum()<=2+1e-7:solutions.append(result)
    assert solutions
    best=max(solutions,key=lambda r:-r.fun);candidate=best.x
    assert float(desirability(candidate)[0])>=float(np.max(dg))-1e-6
    # Use implementable rounded settings, not spurious numerical optimizer precision.
    actual=np.array([85+10*candidate[0],1+.333*candidate[1],1+.2*candidate[2]])
    rounded=np.array([round(actual[0],1),round(actual[1],3),round(actual[2],3)])
    xr=(rounded-np.array([85,1,1]))/np.array([10,.333,.2])
    candidate_rows=[]
    for label,xx in [('数学搜索点（非实测）',candidate),('取整后验证点（非实测）',xr)]:
        pf=prediction(mf,xx,'quadratic');pp=prediction(mp,xx,'linear')
        candidate_rows.append({'说明':label,'温度':85+10*xx[0],'相比':1+.333*xx[1],'初始氟含量':1+.2*xx[2],
             'A':xx[0],'B':xx[1],'C':xx[2],'D':float(desirability(xx)[0]),
             '氟萃取率预测/%':pf['mean'],'氟均值CI下限':pf['mean_ci_lower'],'氟均值CI上限':pf['mean_ci_upper'],
             '氟单次PI下限':pf['obs_ci_lower'],'氟单次PI上限':pf['obs_ci_upper'],
             '磷损失率预测/%':pp['mean'],'磷均值CI下限':pp['mean_ci_lower'],'磷均值CI上限':pp['mean_ci_upper'],
             '磷单次PI下限':pp['obs_ci_lower'],'磷单次PI上限':pp['obs_ci_upper']})
    cand=pd.DataFrame(candidate_rows)
    # Model-form/influence sensitivity is diagnostic only; the primary fit retains all 17 runs.
    sensitivity_candidates=[]
    mask=data.Run!=8
    p_leave8=sm.OLS(data.loc[mask,'P'].to_numpy(),matrix(data.loc[mask,['A','B','C']],'linear')).fit()
    for title,pm,kind in [('磷线性，全17点（主分析）',mp,'linear'),
                          ('磷线性，诊断性留出运行8',p_leave8,'linear'),
                          ('磷完整二次，全17点',models[('P','quadratic')][0],'quadratic')]:
        def alternate_d(xx):
            ff=matrix(xx).to_numpy()@bf;pp=matrix(xx,kind).to_numpy()@pm.params.to_numpy()
            return np.sqrt(np.clip((ff-fmin)/(fmax-fmin),0,1)*np.clip((pmax-pp)/(pmax-pmin),0,1))
        grid_values=alternate_d(grid);ss=np.vstack([grid[np.argsort(grid_values)[-8:]],x,np.zeros((1,3))]);results=[]
        for start in ss:
            r=optimize.minimize(lambda v:-float(alternate_d(v)[0]),start,method='SLSQP',bounds=[(-1,1)]*3,
                 constraints=[{'type':'ineq','fun':lambda v:2-np.abs(v).sum()}],options={'ftol':1e-12,'maxiter':500})
            if r.success and np.abs(r.x).sum()<=2+1e-7:results.append(r)
        assert results
        r=min(results,key=lambda z:z.fun);xx=r.x
        sensitivity_candidates.append({'情景':title,'温度':85+10*xx[0],'相比':1+.333*xx[1],'初始氟含量':1+.2*xx[2],
            '氟预测/%':float((matrix(xx).to_numpy()@bf)[0]),'磷预测/%':float((matrix(xx,kind).to_numpy()@pm.params.to_numpy())[0]),'D':-float(r.fun)})
    candidate_sensitivity=pd.DataFrame(sensitivity_candidates)
    pareto=[]
    for i,row in data.iterrows():
        dominated=((data.F>=row.F)&(data.P<=row.P)&((data.F>row.F)|(data.P<row.P))).any()
        if not dominated:pareto.append(i)
    observed=data.loc[pareto,['Run','Temperature','Ratio','Initial_F','F','P','beta']].sort_values('P')
    data['D_observed']=np.sqrt(np.clip((data.F-fmin)/(fmax-fmin),0,1)*np.clip((pmax-data.P)/(pmax-pmin),0,1))
    observed_best=data.loc[data.D_observed.idxmax()]
    # Save import-ready data in experimental run order, with explicit coded factors.
    data.to_csv(out/'Sheet1_重算数据.csv',index=False,encoding='utf-8-sig',float_format='%.12g')
    import_data=data[['Std','Run','Temperature','Ratio','Initial_F','F','P','beta']].rename(columns={'Temperature':'A_Temperature','Ratio':'B_Phase_ratio','Initial_F':'C_Initial_F','F':'R1_F_extraction_percent','P':'R2_P_loss_percent','beta':'R3_Selectivity_beta'})
    import_data.to_csv(out/'DesignExpert_导入数据.csv',index=False,encoding='utf-8-sig',float_format='%.12g')
    equations={}
    for response,kind in [('F','quadratic'),('P','linear'),('P','quadratic'),('beta','quadratic')]:
        m,_=models[(response,kind)];eq=f'{LABELS[response]} = {m.params.iloc[0]:.6f}'
        for name,val in m.params.iloc[1:].items():eq+=f' {"+" if val>=0 else "−"} {abs(val):.6f}{name}'
        equations[f'{response}_{kind}']=eq
    notes=[
        ('数据依据','用户已确认以Sheet1为准；Sheet2仅用于差异审计及敏感性附表，不替换、不平均两套浓度。原始文件未修改。'),
        ('优化目标','用户确认：同时提高氟萃取率、降低磷损失率。未给经济权重或硬性门槛，本报告用等权几何期望度提供一组探索性验证点。'),
        ('设计','三因素三水平Box–Behnken设计，17次运行、13个独立条件、5次中心重复（运行2/3/11/13/17）。'),
        ('单位与体积假设','原表未注明温度、初始氟含量、浓度和体积单位。沿用Sheet1公式，初始萃余水相体积为50，F列视为萃取后萃余相体积。Sheet2相别表头存在歧义，需结合实验记录核实。'),
        ('重算公式','氟萃取率=100×[1−V后×C氟后/(50×C氟前)]；磷损失率同理。β=[(50C氟前−V后C氟后)/C氟后]÷[(50C磷前−V后C磷后)/C磷后]。'),
        ('选择性系数','β为无量纲分离因子；同次实验共有的有机相体积在比值中抵消。未报告未经相体积核实的单独分配系数。Sheet2少数行的β/100不是标准β，不采用此缩放。'),
        ('编码','A=(温度−85)/10；B=(相比−1)/0.333；C=(初始氟含量−1)/0.2。相比按原表0.667/1.333计算，未替换成精确2/3、4/3。'),
        ('模型与检验','普通最小二乘；α=0.05。主报告保留完整二次方程，单项检验为控制其他项后的偏F检验（非顺序SS）；失拟以5次中心重复估计纯误差。'),
        ('模型选择','氟保留完整二次以描述曲率；磷线性预测R²优于完整二次，且新增交互和平方项不显著，因此验证点使用磷线性模型。未删实验、未调整观测值。'),
        ('预测能力','预测R²=1−PRESS/SST，PRESS由逐次留一法计算；这是内部交叉验证，不能替代独立验证或自动修正模型选择偏差。氟调整与预测R²差约0.216，需验证。'),
        ('异常点','磷线性模型运行8的外学生化残差约4.198、Bonferroni校正p约0.021，属于应优先核查的模型异常点，但不等于已确认测量错误。主分析仍保留全部17点。'),
        ('优化敏感性','仅作诊断的留出运行8会使候选初始氟含量由约1.108变为约0.972，说明优化位置不稳健；磷二次模型也改变预测水平。未以这些替代主分析或删除观测。'),
        ('优化范围','每个编码因素在[−1,1]，且|A|+|B|+|C|≤2，限制在BBD实际设计点凸包内；不在未覆盖的立方体角点寻优。'),
        ('期望度','d氟=clip[(预测氟−观测最小氟)/(观测最大氟−观测最小氟),0,1]；d磷=clip[(观测最大磷−预测磷)/(观测最大磷−观测最小磷),0,1]；D=√(d氟×d磷)。权重均为1。实测排名采用同一归一化范围并代入实测响应，模型搜索代入预测响应。'),
        ('预测区间','CI为模型均值95%区间，PI为同条件下一次独立实验95%预测区间；均以模型正确且独立同方差为前提，不含选模/寻优/原始测量系统误差。'),
        ('验证计划','验证点建议至少3次独立全流程萃取重复，同时测定前后浓度及体积；与邻近中心点比较。结果落在区间内并不等于已证明模型正确。'),
        ('软件','使用Python数值方法重现常用响应面流程，未运行专有Design-Expert软件；CSV可手动映射因素/响应后导入，非原生项目文件。'),
        ('原始SHA256',original_hash),
    ]
    levels=pd.DataFrame({'因素':['A 温度','B 相比','C 初始氟含量'],'低水平':[75,.667,.8],'中心':[85,1,1],'高水平':[95,1.333,1.2],'单位':['原表未标注','原表未解释比值方向','原表未标注']})
    dictionary=pd.DataFrame([
        ('Std','原Sheet1 A列的设计标准序号'),('Run','原Sheet1 B列的运行顺序'),('Temperature','温度，原C列'),
        ('Ratio','相比，原D列，方向未标注'),('Initial_F','初始氟含量因素水平，原E列；区别于测定浓度F_before'),
        ('V_after','萃取后体积，原F列；沿原公式作为萃余相体积'),('F_before','萃取前氟浓度，原J列'),
        ('P_before','萃取前磷浓度，原K列'),('F_after','萃取后氟浓度，原L列'),('P_after','萃取后磷浓度，原M列'),
        ('A/B/C','三个因素的编码值，见说明中的中心与步长'),('F','氟萃取率，单位%'),('P','磷损失率，单位%'),
        ('beta','无量纲氟/磷选择性系数β'),('log_beta','β的自然对数，仅用于探索变换'),
        ('D_observed','用实测响应和原观测范围计算的等权期望度'),('R2','拟合决定系数'),
        ('adj_R2','调整决定系数'),('pred_R2_LOO','逐次留一内部预测决定系数'),('PRESS','留一预测残差平方和'),
        ('RMSE','残差均方根，响应的原量纲'),('model_p','相对仅截距模型的整体F检验p'),
        ('lack_of_fit_p','失拟检验p，以中心重复为纯误差来源'),('adequate_precision','拟合响应极差/√(参数数×残差MS/样本数)'),
        ('CI','固定条件下均值的95%置信区间'),('PI','固定条件下一次新实验的95%预测区间')],columns=['字段','解释'])
    workbook=out/'响应面分析结果.xlsx'
    with pd.ExcelWriter(workbook,engine='openpyxl') as writer:
        pd.DataFrame(notes,columns=['项目','说明']).to_excel(writer,sheet_name='说明',index=False)
        levels.to_excel(writer,sheet_name='因素水平',index=False)
        dictionary.to_excel(writer,sheet_name='字段说明',index=False)
        data.to_excel(writer,sheet_name='Sheet1重算数据',index=False)
        pd.DataFrame(diff).to_excel(writer,sheet_name='两表差异审计',index=False)
        comparison.to_excel(writer,sheet_name='模型比较',index=False)
        pd.DataFrame(steps).to_excel(writer,sheet_name='模型增项检验',index=False)
        pd.DataFrame(anovas).to_excel(writer,sheet_name='模型ANOVA',index=False)
        pd.DataFrame(partial).to_excel(writer,sheet_name='各项偏F检验',index=False)
        pd.DataFrame(coeffs).to_excel(writer,sheet_name='回归系数及区间',index=False)
        pd.DataFrame(diagnostics).to_excel(writer,sheet_name='逐点诊断',index=False)
        observed.to_excel(writer,sheet_name='已有实验Pareto',index=False)
        cand.to_excel(writer,sheet_name='候选验证条件',index=False)
        candidate_sensitivity.to_excel(writer,sheet_name='候选敏感性诊断',index=False)
        pd.DataFrame(sensitivity).to_excel(writer,sheet_name='附_Sheet2敏感性',index=False)
        pd.DataFrame(equations.items(),columns=['模型','编码方程']).to_excel(writer,sheet_name='编码方程',index=False)
        for s in writer.book:
            s.freeze_panes='A2';s.auto_filter.ref=s.dimensions
            for cell in s[1]:cell.fill=PatternFill('solid',fgColor='183C50');cell.font=Font(color='FFFFFF',bold=True)
            for row in s.iter_rows(min_row=2):
                for cell in row:
                    if isinstance(cell.value,(float,np.floating)):
                        heading=str(s.cell(1,cell.column).value)
                        cell.number_format='0.0000E+00' if heading=='p' or heading.endswith('_p') or '校正p' in heading else ('0.00000000' if s.title=='Sheet1重算数据' else '0.0000')
                    cell.alignment=Alignment(vertical='top',wrap_text=True)
            for col in s.columns:
                letter=get_column_letter(col[0].column)
                longest=max(len(str(c.value or '')) for c in col)
                s.column_dimensions[letter].width=min(52,max(12,longest*1.15))
            if s.title=='说明':s.column_dimensions['B'].width=112
    # Publication-quality static plots; embedded in HTML and available individually.
    plot_files=[]
    for response,kind in [('F','quadratic'),('P','linear'),('beta','quadratic')]:
        m,info=models[(response,kind)];infl=m.get_influence();fig,axs=plt.subplots(2,2,figsize=(11,8),layout='constrained')
        ax=axs[0,0];ax.scatter(data[response],m.fittedvalues,c='#187b8c',s=45,edgecolors='white')
        lo=min(data[response].min(),m.fittedvalues.min());hi=max(data[response].max(),m.fittedvalues.max());ax.plot([lo,hi],[lo,hi],'--',color='#c77439')
        ax.set(xlabel='实测值',ylabel='模型拟合值',title='实测与拟合（非独立验证）')
        ax=axs[0,1];ax.scatter(m.fittedvalues,infl.resid_studentized_external,color='#187b8c');ax.axhline(0,color='grey');ax.axhline(3,color='#c77439',ls='--');ax.axhline(-3,color='#c77439',ls='--')
        for j,rr in enumerate(infl.resid_studentized_external):
            if abs(rr)>2:ax.annotate(str(int(data.iloc[j].Run)),(m.fittedvalues.iloc[j],rr))
        ax.set(xlabel='模型拟合值',ylabel='外学生化残差',title='残差与拟合值')
        ax=axs[1,0];stats.probplot(m.resid,dist='norm',plot=ax);ax.set(title='残差正态Q–Q图',xlabel='理论正态分位数',ylabel='残差')
        ax=axs[1,1];ax.plot(data.Run,m.resid,'o-',color='#187b8c');ax.axhline(0,color='grey');ax.set(xlabel='运行顺序',ylabel='残差',title='残差与运行顺序')
        fig.suptitle(f'{LABELS[response]}｜{MODEL_LABELS[kind]}诊断；预测R²={info["pred_R2_LOO"]:.3f}'+('｜失拟显著，仅供诊断' if response=='beta' else ''),fontsize=14)
        p=plots/f'{response}_模型诊断.png';fig.savefig(p);plt.close(fig);plot_files.append(p)
    # Surface slices fix the third factor at the design centre.
    for response,kind in [('F','quadratic'),('P','linear')]:
        m,info=models[(response,kind)];fig=plt.figure(figsize=(16,8),layout='constrained')
        for k,(i,j) in enumerate([(0,1),(0,2),(1,2)]):
            vals=np.linspace(-1,1,65);u,v=np.meshgrid(vals,vals);xx=np.zeros((u.size,3));xx[:,i]=u.ravel();xx[:,j]=v.ravel()
            zz=m.predict(matrix(xx,kind)).to_numpy().reshape(u.shape)
            levels_n=12; ax=fig.add_subplot(2,3,k+1,projection='3d');ax.plot_surface(u,v,zz,cmap='viridis',linewidth=0,alpha=.95)
            ax.set(xlabel='ABC'[i],ylabel='ABC'[j],zlabel=LABELS[response]);ax.view_init(25,-130)
            ax=fig.add_subplot(2,3,k+4);cs=ax.contourf(u,v,zz,levels_n,cmap='viridis');ax.contour(u,v,zz,levels_n,colors='white',linewidths=.45,alpha=.7);fig.colorbar(cs,ax=ax,label=LABELS[response])
            ax.set(xlabel='ABC'[i]+'（编码）',ylabel='ABC'[j]+'（编码）',title='ABC'[3-i-j]+' 固定为0');ax.set_aspect('equal')
        fig.suptitle(f'{LABELS[response]}响应面与等高线｜A温度，B相比，C初始氟含量',fontsize=15)
        p=plots/f'{response}_响应面及等高线.png';fig.savefig(p);plt.close(fig);plot_files.append(p)
    # Measured Pareto points are explicitly separated from model predictions.
    fig,ax=plt.subplots(figsize=(9,6),layout='constrained');ax.scatter(data.P,data.F,color='#76959e',label='17次实测')
    for _,r in data.iterrows():ax.annotate(str(int(r.Run)),(r.P,r.F),xytext=(3,4),textcoords='offset points',fontsize=8)
    ax.plot(observed.P,observed.F,'o-',color='#187b8c',label='实测非支配点')
    rr=cand.iloc[1];ax.scatter(rr['磷损失率预测/%'],rr['氟萃取率预测/%'],marker='*',s=240,color='#c77439',label='待验证候选（模型预测）',zorder=4)
    ax.set(xlabel='磷损失率/%（越低越好）',ylabel='氟萃取率/%（越高越好）',title='氟回收与磷损失的实测权衡');ax.legend()
    p=plots/'实测权衡与候选.png';fig.savefig(p);plt.close(fig);plot_files.append(p)
    # Summary results for verification and reuse.
    payload={'source_sha256':original_hash,'n':len(data),'model_comparison':summaries,'candidate':candidate_rows,
             'observed_best_equal_D':observed_best.to_dict(),'equations':equations,'pareto_runs':[int(data.iloc[i].Run) for i in pareto],
             'candidate_sensitivity':sensitivity_candidates,
             'optimization_grid_count':len(grid),'optimization_grid_best_D':float(np.max(dg)),'successful_optimization_starts':len(solutions)}
    (out/'分析数值.json').write_text(json.dumps(payload,ensure_ascii=False,indent=2),encoding='utf-8')
    def embed(p):return '<img alt="'+html.escape(p.stem)+'" src="data:image/png;base64,'+base64.b64encode(p.read_bytes()).decode()+'">'
    short=comparison[comparison.response!='ln(β)'][['response','model','R2','adj_R2','pred_R2_LOO','model_p','lack_of_fit_p']].rename(columns={'response':'响应','model':'模型','R2':'R²','adj_R2':'调整R²','pred_R2_LOO':'预测R²（LOO）','model_p':'模型p','lack_of_fit_p':'失拟p'})
    rr=cand.iloc[1];obs=observed_best
    hf=pd.DataFrame(coeffs);sig=hf[(hf['响应']==LABELS['F'])&(hf['项']!='Intercept')&(hf['p']<.05)]
    css='''body{font:16px/1.8 system-ui,"Noto Sans CJK SC","Microsoft YaHei",sans-serif;color:#203c49;background:#f4f7f8;margin:0}main{max-width:1140px;margin:auto;background:white;padding:42px}h1{font-size:30px;margin:0}h2{margin-top:36px;border-bottom:2px solid #d8e4e8;padding-bottom:8px}h3{color:#1e6877}table{border-collapse:collapse;width:100%;font-size:13px;display:block;overflow:auto}th,td{padding:9px 12px;border-bottom:1px solid #dce6e9;text-align:left;white-space:nowrap}th{background:#e7f0f3}img{width:100%;height:auto;margin:12px 0}.note{background:#fff5df;border-left:4px solid #c48d30;padding:15px}.card{background:#edf6f7;padding:20px;margin:16px 0}.eq{font:15px/1.9 monospace;overflow-wrap:anywhere;padding:14px;background:#f0f4f5}.small{font-size:13px;color:#59717b}@media print{body{background:white}main{padding:0}h2{break-after:avoid}img,table{break-inside:avoid}}'''
    parts=[f'<!doctype html><html lang="zh-CN"><meta charset="utf-8"><title>响应面实验分析报告</title><style>{css}</style><main>',
       '<p class="small">三因素 Box–Behnken · 17次实验 · 数据来源：响应面实验处理.xlsx / Sheet1</p><h1>氟萃取与磷损失：响应面分析报告</h1>',
       '<div class="card"><b>主要判断</b><p>相比B是最主要的影响因素：提高相比总体上提高氟萃取率，也增加磷损失，存在明确权衡。氟二次模型可用于探索响应面；磷线性模型的内部预测表现优于完整二次。β模型失拟显著，不用于寻优。</p></div>',
       f'<p>本报告依据你确认的Sheet1和“同时提高氟萃取率、降低磷损失率”目标。按下述等权期望度，现有实测中运行<b>{int(obs.Run)}</b>的折中得分最高：温度{obs.Temperature:g}、相比{obs.Ratio:g}、初始氟含量{obs.Initial_F:g}；氟萃取率<b>{obs.F:.2f}%</b>、磷损失率<b>{obs.P:.2f}%</b>。这不是所有权重下的唯一最优条件。</p>',
       '<h2>1. 数据核对与计算口径</h2>',table(levels),
       '<p>17次运行为12个边中点和5个中心重复，中心运行号为2、3、11、13、17。Sheet1的G/H缓存与质量平衡重算一致，I列β为空，已在结果工作簿补算。没有缺失因素/测量值，没有删点或修改观测值。</p>',
       '<div class="note">原表没有写明单位。本报告保留原数值，不擅自标为°C或百分含量。沿用Sheet1公式，将初始水相体积视为50、F列视为萃取后萃余相体积；Sheet2对相别的表头存在歧义，需结合实验记录核实。若该体积解释有误，应重新计算响应。</div>',
       '<p>令V为萃取后萃余相体积，C₀、C₁分别为萃取前后浓度：</p><div class="eq">氟萃取率 = 100 × (1 − V·C氟₁ / (50·C氟₀))<br>磷损失率 = 100 × (1 − V·C磷₁ / (50·C磷₀))<br>β = [(50·C氟₀ − V·C氟₁)/C氟₁] ÷ [(50·C磷₀ − V·C磷₁)/C磷₁]</div>',
       '<p>β中同一运行的有机相体积在分配系数比中抵消，β不再除以100。相比的方向（有机/水相还是相反）未注明，不改变你表中数值的定义。</p>',
       '<h3>两表差异记录</h3><p>运行8、11、13、14有差异。运行13/14的Sheet2值与Sheet1无标题O/P备注相同。按你的确认，正式分析全部采用Sheet1；其余版本仅作审计。</p>',table(pd.DataFrame(diff)),
       '<h2>2. 模型比较与适用性</h2>',table(short),
       '<p>完整二次模型含截距、A/B/C、AB/AC/BC和A²/B²/C²，共10个参数；残差自由度7，纯误差自由度4，失拟自由度3。预测R²基于逐次留一法PRESS，并与显式逐次重拟合交叉核对。它是内部验证，不能替代新增实验。</p>',
       f'<ul><li><b>氟萃取率：</b>完整二次R²={fi["R2"]:.4f}，预测R²={fi["pred_R2_LOO"]:.4f}。模型显著；失拟p={fi["lack_of_fit_p"]:.4f}，仅略高于0.05，不能据此认定不存在失拟。调整/预测R²相差{fi["adj_R2"]-fi["pred_R2_LOO"]:.3f}，候选条件必须验证。</li>',
       f'<li><b>磷损失率：</b>线性预测R²={pi["pred_R2_LOO"]:.4f}，完整二次预测R²={models[("P","quadratic")][1]["pred_R2_LOO"]:.4f}。增加交互、平方项均未显著改善，因此折中搜索选用较简约的线性模型；但运行8存在异常残差，候选并不稳健，详见敏感性分析。</li>',
       '<li><b>选择性系数β：</b>完整二次整体p=0.0543，失拟p=0.0136，预测R²为负。ln(β)变换也没有解决失拟，详见Excel模型比较。β仅作实测描述，不给出“最优β”预测。</li></ul>',
       '<h3>编码与回归方程</h3><div class="eq">A=(温度−85)/10；B=(相比−1)/0.333；C=(初始氟含量−1)/0.2</div>',
       '<div class="eq">'+html.escape(equations['F_quadratic'])+'</div>',
       '<div class="eq">'+html.escape(equations['P_linear'])+'</div>',
       '<p>氟二次模型的显著项（α=0.05）为A、B、BC、B²。保留其他项以维持完整二次基准和模型层级；显著性并不直接等于工程影响大小。磷模型中相比B主导变化。</p>',
       '<h3>模型方差分析</h3>',table(pd.DataFrame(anovas).query('响应 != "ln(β)"')),
       '<h2>3. 诊断与响应面</h2>',
       '<p>氟二次模型的运行9、15外学生化残差约为±4.72，且Cook距离较高，建议核对原始测量与实验操作。它们未超过该模型Bonferroni 5%阈值约4.82，未被删除。<b>磷线性模型中，运行8外学生化残差约4.20、Cook距离约0.864，Bonferroni校正p≈0.021，应优先核查。</b>这是相对当前模型的异常标记，不证明测量错误；主分析保留全部17点。完整逐点诊断在结果Excel中。</p>',
       *[embed(p) for p in plot_files[:3]],
       '<p>下图每幅固定第三因素在中心水平，展示编码范围[−1,1]内的切片；曲面表示模型预测而非实测。</p>',
       *[embed(p) for p in plot_files[3:5]],
       '<h2>4. 折中条件与验证计划</h2>',embed(plot_files[-1]),table(observed),
       '<p>上表是当前17次实测中的非支配点：没有另一实测点同时具有更高氟萃取率和更低磷损失率。不存在无需设定取舍的单一“最佳点”。</p>',
       '<h3>等权期望度定义</h3><div class="eq">d氟 = clip[(预测氟 − 观测最小氟)/(观测最大氟 − 观测最小氟), 0, 1]<br>d磷 = clip[(观测最大磷 − 预测磷)/(观测最大磷 − 观测最小磷), 0, 1]<br>D = √(d氟 × d磷)</div>',
       f'<p>氟观测范围{fmin:.4f}–{fmax:.4f}%，磷观测范围{pmin:.4f}–{pmax:.4f}%。两目标同等权重；实测排名在同一公式中代入实测响应，模型搜索代入预测响应。搜索限制在BBD设计点凸包内（各编码∈[−1,1]且|A|+|B|+|C|≤2），避免立方体角点外推。采用{len(grid):,}个网格点和多起点连续搜索交叉检查。</p>',
       f'<div class="card"><b>优先复验运行9，并比较以下探索候选：</b>温度 <b>{rr["温度"]:.1f}</b>、相比 <b>{rr["相比"]:.3f}</b>、初始氟含量 <b>{rr["初始氟含量"]:.3f}</b>（均沿用原表单位）。<br>候选预测氟萃取率 <b>{rr["氟萃取率预测/%"]:.2f}%</b>，磷损失率 <b>{rr["磷损失率预测/%"]:.2f}%</b>。其预测D低于运行9的实测D，不宣称优于现有实验；预测与单次实测包含不同的不确定性。</div>',
       table(cand),
       '<p>CI为条件均值95%置信区间，PI为一次新实验95%预测区间，两者不同。区间基于拟合模型正确、误差独立同方差的假设，没有计入选模、寻优或测量系统误差，因此不能把候选预测当作实测承诺。若区间跨出物理边界，也保留原统计区间，不靠截断制造确定性。</p>',
       '<h3>候选位置的敏感性</h3>',table(candidate_sensitivity),
       '<p>诊断性留出运行8会明显改变候选初始氟含量，说明这一位置不稳健；仅更换磷模型形式也会改变预测损失率。上述留出仅用于影响分析，不是删除数据后的“修正结果”，也不是主分析。β失拟、氟模型的预测差距和这些敏感性共同说明：目前适合提出验证方案，不适合直接确定工艺最优值。</p>',
       '<p>建议优先在运行9条件及取整后候选条件各开展至少3次独立全流程重复（不是同一萃取液反复读数），同时记录两相体积与萃取前后浓度；与中心条件比较，再根据实际可接受的磷损失上限细化优化。</p>',
       '<h2>5. 交付与可复现性</h2><p>结果Excel含重算数据、因素编码、模型比较、增项检验、ANOVA、各项偏F检验、回归系数及95%区间、逐点诊断、实测Pareto点、候选及预测区间、Sheet2敏感性附表。CSV保留全精度，可按列手动映射到Design-Expert。文件包同时含Python分析脚本和依赖版本。</p>',
       '<p class="small">计算采用Python/NumPy/SciPy/statsmodels，未运行专有Design-Expert软件。完整报告为独立HTML，图像已嵌入，可离线查看或浏览器打印成PDF。原始文件未修改；SHA256：'+original_hash+'</p></main></html>']
    (out/'响应面分析报告.html').write_text('\n'.join(parts),encoding='utf-8')
    import importlib.metadata as md
    req='\n'.join(f'{name}=={md.version(name)}' for name in ['numpy','pandas','scipy','statsmodels','matplotlib','openpyxl'])+'\n'
    (out/'requirements.txt').write_text(req,encoding='utf-8')
    if Path(__file__).resolve()!=out/'analyze.py':shutil.copy2(__file__,out/'analyze.py')
    shutil.copy2(source,out/'原始数据_未修改.xlsx')
    (out/'复现说明.txt').write_text('数据源：原始数据_未修改.xlsx（与上传文件字节一致）。\n采用用户确认的Sheet1；两目标等权仅为探索性默认。\nPython 3.12；安装requirements.txt中版本。\n运行：python analyze.py 原始数据_未修改.xlsx --output 重新分析结果\n生成代码仅写输出目录，不更改输入。因未安装专有软件，不提供Design-Expert原生项目文件。\n',encoding='utf-8')
    assert hashlib.sha256(source.read_bytes()).hexdigest()==original_hash
    # Verify generated workbook values and row counts by reopening the delivered file.
    check=load_workbook(workbook,data_only=True)
    assert check['Sheet1重算数据'].max_row==18
    assert check['候选验证条件'].max_row==3
    assert len(check.sheetnames)==16
    if Path('/workspace/scratch/response_surface/independent_models.json').exists():
        ind=json.loads(Path('/workspace/scratch/response_surface/independent_models.json').read_text())
        for r,key in [('F','F'),('P','P'),('beta','beta')]:
            if key not in ind:continue
            for kind,ik in [('linear','linear'),('quadratic','quadratic')]:
                if ik in ind[key]['models']:
                    assert np.isclose(models[(r,kind)][1]['R2'],ind[key]['models'][ik]['r2'],rtol=1e-9)
    zip_path=out.parent/'响应面分析完整文件包.zip'
    with zipfile.ZipFile(zip_path,'w',zipfile.ZIP_DEFLATED) as z:
        for file in sorted(out.rglob('*')):
            if file.is_file():z.write(file,arcname=out.name+'/'+str(file.relative_to(out)))
    print(short.to_string(index=False))
    print('\nCANDIDATE\n'+cand.to_string(index=False))
    print('\nMEASURED BEST\n'+observed_best.to_string())
    print('\nOUTPUT',out,'ZIP',zip_path)

if __name__=='__main__':main()
