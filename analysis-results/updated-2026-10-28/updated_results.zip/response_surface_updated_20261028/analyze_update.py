#!/usr/bin/env python3
"""Analyze the user-confirmed, corrected Design-Expert screenshot values."""
import argparse, base64, hashlib, html, importlib.metadata, json, os, shutil, tempfile, zipfile
from pathlib import Path
os.environ.setdefault('MPLCONFIGDIR',str(Path(tempfile.gettempdir())/'response_surface_mplconfig'))
import numpy as np
import pandas as pd
from scipy import stats, optimize
import statsmodels.api as sm
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib import font_manager
from openpyxl import load_workbook
from openpyxl.styles import Font, PatternFill, Alignment
from openpyxl.utils import get_column_letter

TERMS=['Intercept','A','B','C','AB','AC','BC','A²','B²','C²']
LABELS={'F':'氟萃取率/%','P':'磷萃取率/%','beta':'氟选择性系数β'}
KINDS={'linear':'线性','2FI':'双因素交互','quadratic':'完整二次'}

def matrix(x,kind='quadratic'):
    a,b,c=np.atleast_2d(x).T
    z=np.column_stack([np.ones(len(a)),a,b,c,a*b,a*c,b*c,a*a,b*b,c*c])
    n={'linear':4,'2FI':7,'quadratic':10}[kind]
    return pd.DataFrame(z[:,:n],columns=TERMS[:n])

def fit(d,response,kind):
    y=d[response].to_numpy();x=matrix(d[['A','B','C']],kind);m=sm.OLS(y,x).fit()
    inf=m.get_influence();press=float(np.sum((m.resid/(1-inf.hat_matrix_diag))**2))
    pure=sum(float(np.sum((g[response]-g[response].mean())**2)) for _,g in d.groupby(['A','B','C']))
    pure_df=len(d)-len(d.groupby(['A','B','C']));lof_df=int(m.df_resid)-pure_df
    lof_ss=max(0,float(m.ssr)-pure);lof_f=lof_ss/lof_df/(pure/pure_df)
    r={'响应':LABELS[response],'模型':KINDS[kind],'R²':float(m.rsquared),'调整R²':float(m.rsquared_adj),
       '预测R²_LOO':float(1-press/m.centered_tss),'调整预测差值':float(m.rsquared_adj-(1-press/m.centered_tss)),
       'PRESS':press,'残差标准差':float(np.sqrt(m.mse_resid)),'CV_%':float(100*np.sqrt(m.mse_resid)/np.mean(y)),
       'Adeq_Precision':float(np.ptp(m.fittedvalues)/np.sqrt(x.shape[1]*m.mse_resid/len(d))),
       '模型_F':float(m.fvalue),'模型_p':float(m.f_pvalue),'失拟_F':lof_f,'失拟_p':float(stats.f.sf(lof_f,lof_df,pure_df)),
       '纯误差_SS':pure,'纯误差_df':pure_df,'失拟_SS':lof_ss,'失拟_df':lof_df,'残差_df':int(m.df_resid)}
    # Independently refit every held-out observation; preserve all input values.
    errors=[];xx=x.to_numpy()
    for i in range(len(y)):
        keep=np.arange(len(y))!=i
        b=np.linalg.lstsq(xx[keep],y[keep],rcond=None)[0];errors.append(y[i]-xx[i]@b)
    assert np.isclose(np.sum(np.square(errors)),press,rtol=1e-9)
    return m,r

def equation(m,kind,actual=False):
    b=np.zeros(10);b[:len(m.params)]=m.params
    if actual:
        centre=np.array([85.,1.,1.]);step=np.array([10.,.333,.2]);v=centre/step
        q=np.array([[b[7],b[4]/2,b[5]/2],[b[4]/2,b[8],b[6]/2],[b[5]/2,b[6]/2,b[9]]])
        linear=b[1:4];intercept=b[0]-linear@v+v@q@v;new_linear=(linear-2*q@v)/step;new_q=q/np.outer(step,step)
        b=np.array([intercept,*new_linear,2*new_q[0,1],2*new_q[0,2],2*new_q[1,2],*np.diag(new_q)])
        names=['Intercept','T','R','C₀','T·R','T·C₀','R·C₀','T²','R²','C₀²']
    else:names=TERMS
    n={'linear':4,'2FI':7,'quadratic':10}[kind];text=f'{b[0]:.7f}'
    for name,val in zip(names[1:n],b[1:n]):text+=f' {"+" if val>=0 else "−"} {abs(val):.7f}{name}'
    return text

def main():
    ap=argparse.ArgumentParser();ap.add_argument('source');ap.add_argument('--previous',required=True);ap.add_argument('--output',required=True);args=ap.parse_args()
    source=Path(args.source);previous=Path(args.previous);out=Path(args.output);out.mkdir(parents=True,exist_ok=True);plots=out/'plots';plots.mkdir(exist_ok=True)
    source_sha=hashlib.sha256(source.read_bytes()).hexdigest();d=pd.read_csv(source);old=pd.read_csv(previous)
    d['A']=(d.Temperature-85)/10;d['B']=(d.Ratio-1)/.333;d['C']=(d.Initial_F-1)/.2
    x=d[['A','B','C']].to_numpy();assert len(d)==17 and len(np.unique(x,axis=0))==13 and np.linalg.matrix_rank(matrix(x))==10
    assert d.Run.tolist()==list(range(1,18)) and np.all((d[['F','P']]>0)&(d[['F','P']]<100))
    beta_check=d.F*(100-d.P)/(d.P*(100-d.F));d['beta_check_from_rounded_rates']=beta_check;d['beta_check_difference']=d.beta-beta_check
    assert np.max(np.abs(d.beta-beta_check))<.002
    changes=[]
    for i,row in d.iterrows():
        for response,tol in [('F',.00006),('P',.00006),('beta',.002)]:
            if abs(row[response]-old.iloc[i][response])>tol:
                changes.append({'运行':int(row.Run),'响应':LABELS[response],'原Excel值':float(old.iloc[i][response]),'更正截图值':float(row[response]),'差值':float(row[response]-old.iloc[i][response])})
    models={};summaries=[];anova=[];terms=[];coefs=[];diags=[];eqs=[];version_compare=[]
    for response in LABELS:
        for kind in KINDS:
            m,r=fit(d,response,kind);models[(response,kind)]=(m,r);summaries.append(r)
            if kind!='quadratic' and not(response=='P' and kind=='linear'):continue
            keys={'响应':LABELS[response],'模型':KINDS[kind]}
            parts=[('模型',float(m.centered_tss-m.ssr),int(m.df_model),float(m.fvalue),float(m.f_pvalue)),
              ('残差',float(m.ssr),int(m.df_resid),None,None),('失拟',r['失拟_SS'],r['失拟_df'],r['失拟_F'],r['失拟_p']),
              ('纯误差',r['纯误差_SS'],r['纯误差_df'],None,None),('校正总和',float(m.centered_tss),len(d)-1,None,None)]
            for name,ss,df,ff,pp in parts:anova.append({**keys,'来源':name,'SS':ss,'df':df,'MS':ss/df,'F':ff,'p':pp})
            ci=m.conf_int();xx=m.model.exog;y=m.model.endog
            for j,name in enumerate(m.model.exog_names):
                coefs.append({**keys,'项':name,'系数':float(m.params.iloc[j]),'SE':float(m.bse.iloc[j]),'t':float(m.tvalues.iloc[j]),'p':float(m.pvalues.iloc[j]),'CI95下限':ci.iloc[j,0],'CI95上限':ci.iloc[j,1]})
                if j:
                    reduced=sm.OLS(y,np.delete(xx,j,axis=1)).fit();ss=max(0,float(reduced.ssr-m.ssr));ff=ss/m.mse_resid
                    terms.append({**keys,'项':name,'偏SS':ss,'df':1,'F':ff,'p':float(stats.f.sf(ff,1,m.df_resid))})
            inf=m.get_influence();ext=inf.resid_studentized_external;bonf=stats.t.ppf(1-.05/(2*len(d)),int(m.df_resid)-1)
            for i,row in d.iterrows():diags.append({**keys,'运行':int(row.Run),'实测':row[response],'拟合':float(m.fittedvalues.iloc[i]),'残差':float(m.resid.iloc[i]),
                '外学生化残差':ext[i],'Cook_D':inf.cooks_distance[0][i],'杠杆值':inf.hat_matrix_diag[i],
                'Bonferroni校正p':min(1.,float(2*len(d)*stats.t.sf(abs(ext[i]),int(m.df_resid)-1))),'Bonferroni临界值':bonf})
            eqs.extend([{**keys,'表达':'编码因素','方程':equation(m,kind)},{**keys,'表达':'实际因素','方程':equation(m,kind,True)}])
            for version,dd in [('原Excel',old),('已核实更正截图',d)]:
                if 'A' not in dd:dd=dd.assign(A=(dd.Temperature-85)/10,B=(dd.Ratio-1)/.333,C=(dd.Initial_F-1)/.2)
                _,rr=fit(dd,response,kind)
                version_compare.append({'版本':version,**{k:rr[k] for k in ['响应','模型','R²','调整R²','预测R²_LOO','调整预测差值','失拟_p']}})
    summary=pd.DataFrame(summaries);mf,fi=models[('F','quadratic')];mp,pi=models[('P','linear')]
    fmin,fmax=float(d.F.min()),float(d.F.max());pmin,pmax=float(d.P.min()),float(d.P.max())
    def score(ff,pp):return np.sqrt(np.clip((ff-fmin)/(fmax-fmin),0,1)*np.clip((pmax-pp)/(pmax-pmin),0,1))
    bf=mf.params.to_numpy();bp=mp.params.to_numpy()
    def predict(xx):
        z=matrix(xx).to_numpy();return z@bf,z[:,:4]@bp
    def objective(xx):
        ff,pp=predict(xx);return score(ff,pp)
    axis=np.linspace(-1,1,41);grid=np.array(np.meshgrid(axis,axis,axis,indexing='ij')).reshape(3,-1).T;grid=grid[np.abs(grid).sum(axis=1)<=2+1e-12]
    dg=objective(grid);starts=np.vstack([grid[np.argsort(dg)[-12:]],x,np.zeros((1,3))]);solutions=[]
    for start in starts:
        r=optimize.minimize(lambda v:-float(objective(v)[0]),start,method='SLSQP',bounds=[(-1,1)]*3,constraints=[{'type':'ineq','fun':lambda v:2-np.abs(v).sum()}],options={'ftol':1e-12,'maxiter':600})
        if r.success and np.abs(r.x).sum()<=2+1e-7:solutions.append(r)
    best=min(solutions,key=lambda r:r.fun);cx=best.x;assert -best.fun>=np.max(dg)-1e-6
    actual=np.array([85,1,1])+np.array([10,.333,.2])*cx;rounded=np.array([round(actual[0],1),round(actual[1],3),round(actual[2],3)])
    rx=(rounded-np.array([85,1,1]))/np.array([10,.333,.2]);assert np.abs(rx).sum()<=2+1e-7
    candidates=[]
    for name,xx in [('数值搜索点，非实测',cx),('取整验证点，非实测',rx)]:
        pf=mf.get_prediction(matrix(xx)).summary_frame().iloc[0];pp=mp.get_prediction(matrix(xx,'linear')).summary_frame().iloc[0]
        candidates.append({'说明':name,'温度/°C':85+10*xx[0],'相比':1+.333*xx[1],'初始氟含量/%':1+.2*xx[2],'D':float(objective(xx)[0]),
            '氟预测/%':pf['mean'],'氟均值CI下限':pf['mean_ci_lower'],'氟均值CI上限':pf['mean_ci_upper'],'氟单次PI下限':pf['obs_ci_lower'],'氟单次PI上限':pf['obs_ci_upper'],
            '磷预测/%':pp['mean'],'磷均值CI下限':pp['mean_ci_lower'],'磷均值CI上限':pp['mean_ci_upper'],'磷单次PI下限':pp['obs_ci_lower'],'磷单次PI上限':pp['obs_ci_upper']})
    cand=pd.DataFrame(candidates);d['D_observed']=score(d.F,d.P)
    group=d.groupby(['Temperature','Ratio','Initial_F'],as_index=False).agg(n=('Run','count'),Runs=('Run',lambda s:','.join(map(str,s))),F_mean=('F','mean'),F_SD=('F','std'),P_mean=('P','mean'),P_SD=('P','std'),beta_mean=('beta','mean'))
    group['D_from_means']=score(group.F_mean,group.P_mean);group=group.sort_values('D_from_means',ascending=False)
    def pareto(frame,f,p):
        return [i for i,r in frame.iterrows() if not ((frame[f]>=r[f])&(frame[p]<=r[p])&((frame[f]>r[f])|(frame[p]<r[p]))).any()]
    obs_pareto=d.loc[pareto(d,'F','P'),['Run','Temperature','Ratio','Initial_F','F','P','beta','D_observed']].sort_values('P')
    group_pareto=group.loc[pareto(group,'F_mean','P_mean')].sort_values('P_mean');single_best=d.loc[d.D_observed.idxmax()];group_best=group.iloc[0]
    source_copy=out/'source_screenshot_values.csv';previous_copy=out/'previous_version_values.csv'
    if source.resolve()!=source_copy.resolve():shutil.copy2(source,source_copy)
    if previous.resolve()!=previous_copy.resolve():shutil.copy2(previous,previous_copy)
    d[['Std','Run','Temperature','Ratio','Initial_F','F','P','beta']].rename(columns={'Temperature':'A_Temperature_degC','Ratio':'B_Phase_ratio','Initial_F':'C_Initial_F_percent','F':'R1_F_extraction_percent','P':'R2_P_extraction_percent','beta':'R3_Selectivity_beta'}).to_csv(out/'design_expert_import.csv',index=False,encoding='utf-8-sig',float_format='%.12g')
    notes=[('数据来源','用户最新Design-Expert截图；用户已确认运行8/9/15/17为复测或核实更正后的正式数据。只按截图可见小数录入，未取得更正后的完整精度原始测量工作簿。'),
      ('版本关系','本报告对应更正截图版本。原Excel报告仍保留；统计量变化主要来自数据版本变化，不能归因于模型简化。'),
      ('响应名称','F=氟萃取率%；P=磷萃取率%（优化时按此前目标作为磷损失最小化）；beta=氟选择性系数，无量纲。'),
      ('因素单位','A=温度°C；B=相比，方向未注明；C=初始氟含量%。C=1表示原表1%，不是0.01。'),
      ('编码','A=(温度−85)/10；B=(相比−1)/0.333；C=(初始氟含量−1)/0.2。实际方程T/R/C₀分别为温度、相比、初始氟含量。'),
      ('数据处理','直接拟合截图响应值，不用旧版浓度或体积反推更正响应；β保留截图数值，仅用F(100−P)/[P(100−F)]作舍入一致性检查。未删除任何实验。'),
      ('实验设计','17次三因素三水平Box–Behnken，13个独立工况，5次中心重复（运行2/3/11/13/17）；完整二次含10参数，残差df7、纯误差df4、失拟df3。'),
      ('检验','α=0.05；单项为控制其他项后的偏F检验；预测R²=1−PRESS/SST，显式逐次留一重拟合与解析PRESS交叉核验。'),
      ('模型选择','F保留预先比较的完整二次；P线性内部预测优于完整二次，故折中搜索采用P线性；β二次失拟显著，不用于可靠寻优。'),
      ('预测R²限制','留一预测是当前数据上的内部验证；更正数据应保留可追溯原始记录。高预测R²不能替代新的独立实验验证。'),
      ('重复工况','逐运行得分最高不等于该工况复现均值最高。工况汇总表先平均响应再计算D；n=1时SD不可估计，留空。'),
      ('期望度','两目标等权：D=√[clip((F−Fmin)/(Fmax−Fmin),0,1)×clip((Pmax−P)/(Pmax−Pmin),0,1)]。范围固定为本版17次观测极值；实测排名用实测值，寻优用预测值。'),
      ('范围','各因素编码[−1,1]且|A|+|B|+|C|≤2，限制在BBD设计点凸包内。候选仅供验证，不代表已证明最佳工艺。'),
      ('区间','CI为固定条件下模型均值95%置信区间；PI为一次新实验95%预测区间。未包含选模、寻优、测量系统及截图舍入不确定性。'),
      ('验证建议','优先比较候选点、运行9工况和中心工况，至少3次独立全流程重复；保留前后浓度、相体积及仪器原始记录。'),
      ('软件','Python NumPy/SciPy/statsmodels数值计算；未运行专有Design-Expert，输出CSV需手动映射因素/响应。'),('截图转录CSV_SHA256',source_sha)]
    sheets={'说明':pd.DataFrame(notes,columns=['项目','说明']),'截图数据及编码':d,'与原Excel差异':pd.DataFrame(changes),'模型比较':summary,
        '数据版本比较':pd.DataFrame(version_compare),'模型ANOVA':pd.DataFrame(anova),'各项偏F检验':pd.DataFrame(terms),'回归系数及区间':pd.DataFrame(coefs),
        '编码及实际方程':pd.DataFrame(eqs),'逐点诊断':pd.DataFrame(diags),'逐运行Pareto':obs_pareto,'按工况汇总':group,'工况均值Pareto':group_pareto,'候选及预测区间':cand}
    with pd.ExcelWriter(out/'results.xlsx',engine='openpyxl') as writer:
        for name,df in sheets.items():
            df.to_excel(writer,sheet_name=name,index=False);s=writer.book[name];s.freeze_panes='A2';s.auto_filter.ref=s.dimensions
            for cell in s[1]:cell.fill=PatternFill('solid',fgColor='183C50');cell.font=Font(color='FFFFFF',bold=True)
            for row in s.iter_rows(min_row=2):
                for cell in row:
                    head=str(s.cell(1,cell.column).value)
                    if isinstance(cell.value,float):cell.number_format='0.0000E+00' if head=='p' or head.endswith('_p') or '校正p' in head else '0.000000'
                    cell.alignment=Alignment(vertical='top',wrap_text=True)
            for col in s.columns:s.column_dimensions[get_column_letter(col[0].column)].width=min(52,max(12,max(len(str(c.value or '')) for c in col)*1.1))
            if name=='说明':s.column_dimensions['B'].width=112
    fp=Path('/usr/share/fonts/opentype/noto/NotoSansCJK-Regular.ttc')
    if fp.exists():font_manager.fontManager.addfont(str(fp));plt.rcParams['font.family']=font_manager.FontProperties(fname=str(fp)).get_name()
    plt.rcParams.update({'axes.unicode_minus':False,'font.size':10,'savefig.dpi':180,'axes.spines.top':False,'axes.spines.right':False})
    images=[]
    for response,kind in [('F','quadratic'),('P','linear'),('beta','quadratic')]:
        m,r=models[(response,kind)];inf=m.get_influence();fig,axs=plt.subplots(2,2,figsize=(11,8),layout='constrained')
        ax=axs[0,0];ax.scatter(d[response],m.fittedvalues,c='#187b8c',edgecolors='white',s=45);lo=min(d[response].min(),m.fittedvalues.min());hi=max(d[response].max(),m.fittedvalues.max());ax.plot([lo,hi],[lo,hi],'--',color='#c77439');ax.set(xlabel='实测值',ylabel='模型拟合值',title='实测与拟合（参与建模的数据）')
        ax=axs[0,1];ax.scatter(m.fittedvalues,inf.resid_studentized_external,color='#187b8c');ax.axhline(0,color='grey');ax.axhline(3,color='#c77439',ls='--');ax.axhline(-3,color='#c77439',ls='--');ax.set(xlabel='模型拟合值',ylabel='外学生化残差',title='残差与拟合值')
        for i,val in enumerate(inf.resid_studentized_external):
            if abs(val)>2:ax.annotate(str(int(d.iloc[i].Run)),(m.fittedvalues.iloc[i],val))
        ax=axs[1,0];stats.probplot(m.resid,plot=ax);ax.set(title='残差正态Q–Q图',xlabel='理论正态分位数',ylabel='残差')
        ax=axs[1,1];ax.plot(d.Run,m.resid,'o-',color='#187b8c');ax.axhline(0,color='grey');ax.set(xlabel='运行顺序',ylabel='残差',title='残差与运行顺序')
        fig.suptitle(f'{LABELS[response]}｜{KINDS[kind]}\nR²={r["R²"]:.4f}｜调整R²={r["调整R²"]:.4f}｜预测R²={r["预测R²_LOO"]:.4f}',fontsize=13)
        p=plots/f'{response}_diagnostics.png';fig.savefig(p);plt.close(fig);images.append(p)
    for response,kind in [('F','quadratic'),('P','linear')]:
        m,_=models[(response,kind)];fig=plt.figure(figsize=(16,8),layout='constrained')
        for k,(i,j) in enumerate([(0,1),(0,2),(1,2)]):
            v=np.linspace(-1,1,65);u,w=np.meshgrid(v,v);xx=np.zeros((u.size,3));xx[:,i]=u.ravel();xx[:,j]=w.ravel();zz=m.predict(matrix(xx,kind)).to_numpy().reshape(u.shape)
            ax=fig.add_subplot(2,3,k+1,projection='3d');ax.plot_surface(u,w,zz,cmap='viridis',alpha=.95);ax.set(xlabel='ABC'[i],ylabel='ABC'[j],zlabel=LABELS[response]);ax.view_init(25,-130)
            ax=fig.add_subplot(2,3,k+4);cs=ax.contourf(u,w,zz,12,cmap='viridis');ax.contour(u,w,zz,12,colors='white',linewidths=.45,alpha=.7);fig.colorbar(cs,ax=ax,label=LABELS[response]);ax.set(xlabel='ABC'[i]+'（编码）',ylabel='ABC'[j]+'（编码）',title='ABC'[3-i-j]+'固定为0');ax.set_aspect('equal')
        fig.suptitle(LABELS[response]+'响应面｜A温度，B相比，C初始氟含量',fontsize=14);p=plots/f'{response}_surfaces.png';fig.savefig(p);plt.close(fig);images.append(p)
    fig,ax=plt.subplots(figsize=(9,6),layout='constrained');ax.scatter(d.P,d.F,color='#9ab1b7',label='逐次实测')
    for _,rr in d.iterrows():ax.annotate(str(int(rr.Run)),(rr.P,rr.F),xytext=(3,4),textcoords='offset points',fontsize=8)
    ax.scatter(group.P_mean,group.F_mean,s=65,facecolors='none',edgecolors='#187b8c',label='各工况响应均值');rr=cand.iloc[1];ax.scatter(rr['磷预测/%'],rr['氟预测/%'],marker='*',s=240,color='#c77439',label='候选模型预测')
    ax.set(xlabel='磷萃取率/%（目标降低）',ylabel='氟萃取率/%（目标提高）',title='实测、重复工况均值与待验证候选');ax.legend();p=plots/'tradeoff.png';fig.savefig(p);plt.close(fig);images.append(p)
    payload={'source':'User-confirmed corrected Design-Expert screenshot; displayed precision only','source_csv_sha256':source_sha,'models':summaries,
        'coefficients':coefs,'candidates':candidates,'single_best':single_best.to_dict(),'group_best':group_best.to_dict(),
        'changed_runs':sorted(set(c['运行'] for c in changes)),'beta_consistency_max_abs':float(np.max(np.abs(d.beta-beta_check))),
        'optimization_grid_count':len(grid),'optimization_successful_starts':len(solutions)}
    def json_safe(obj):
        if isinstance(obj,dict):return {k:json_safe(v) for k,v in obj.items()}
        if isinstance(obj,(list,tuple)):return [json_safe(v) for v in obj]
        if isinstance(obj,(float,np.floating)) and not np.isfinite(obj):return None
        return obj
    (out/'analysis.json').write_text(json.dumps(json_safe(payload),ensure_ascii=False,indent=2,allow_nan=False),encoding='utf-8')
    def table(df):return df.to_html(index=False,border=0,float_format=lambda v:f'{v:.6g}',na_rep='—')
    def image(p):return '<img alt="'+html.escape(p.stem)+'" src="data:image/png;base64,'+base64.b64encode(p.read_bytes()).decode()+'">'
    css='body{font:16px/1.8 system-ui,"Microsoft YaHei",sans-serif;background:#f4f7f8;color:#203c49;margin:0}main{max-width:1140px;margin:auto;background:white;padding:42px}h1{font-size:30px}h2{margin-top:36px;border-bottom:2px solid #d8e4e8;padding-bottom:8px}table{border-collapse:collapse;width:100%;display:block;overflow:auto;font-size:13px}td,th{padding:9px 12px;border-bottom:1px solid #dce6e9;white-space:nowrap;text-align:left}th{background:#e7f0f3}img{width:100%;height:auto}.card{background:#edf6f7;padding:20px}.note{background:#fff5df;border-left:4px solid #c48d30;padding:15px}.eq{font:14px/1.8 monospace;background:#f0f4f5;padding:14px;overflow-wrap:anywhere}.small{font-size:13px;color:#59717b}@media print{main{padding:0}img,table{break-inside:avoid}}'
    key_summary=summary[(summary['模型']=='完整二次')|((summary['响应']==LABELS['P'])&(summary['模型']=='线性'))][['响应','模型','R²','调整R²','预测R²_LOO','调整预测差值','模型_p','失拟_p']]
    centre=group[group.n==5].iloc[0];rr=cand.iloc[1]
    parts=['<!doctype html><html lang="zh-CN"><meta charset="utf-8"><title>响应面分析：已核实更正数据</title><style>'+css+'</style><main>',
      '<p class="small">正式更正数据版本 · 根据最新Design-Expert截图显示精度计算 · 原Excel报告保留</p><h1>氟与磷萃取：更正数据响应面分析</h1>',
      f'<div class="card"><b>主要结果</b><p>氟完整二次模型R²={fi["R²"]:.4f}、调整R²={fi["调整R²"]:.4f}、预测R²={fi["预测R²_LOO"]:.4f}，调整/预测差值={fi["调整预测差值"]:.4f}；失拟p={fi["失拟_p"]:.4f}。磷建议使用线性预测模型，β完整二次模型仍失拟显著，不用于可靠寻优。</p></div>',
      '<h2>1. 数据版本与单位</h2><p>用户已确认截图中运行8、9、15、17为复测或核实更正后的正式数据。17次运行的因素设计保持不变；除这4次的实质响应更新外，其他差异为显示舍入。这是数据版本变化，不能把改善的统计量归因于算法或模型简化。</p>',
      '<div class="note">本版直接使用截图响应值；尚无更正后的完整精度测量工作簿，无法仅凭截图重新核算浓度和体积质量平衡。截图β按原显示值保留，未用已舍入的F/P覆盖。数值可能与软件内部全精度结果有末位差异。</div>',
      '<p>A：温度（°C），水平75/85/95；B：相比（方向未说明），水平0.667/1/1.333；C：初始氟含量（%），水平0.8/1/1.2。响应1为氟萃取率%，响应2按截图保留“磷萃取率%”（优化时视为磷损失最小化），响应3为无量纲β。</p>',table(pd.DataFrame(changes)),
      '<p>设计为17次三因素三水平Box–Behnken，含12个边中点和5次中心重复。β一致性检查公式为β=F(100−P)/[P(100−F)]，最大绝对差约'+f'{payload["beta_consistency_max_abs"]:.6g}'+'，与截图有限显示精度相符。</p>',
      '<h2>2. 模型结果与旧版比较</h2>',table(key_summary),
      '<p>F完整二次在当前数据上具有较好的内部预测诊断，保留完整二次即可。P二次的预测R²明显低于线性模型，因此折中搜索使用P线性。β虽整体模型显著，但失拟显著且预测R²为负，说明整体显著并不保证可靠预测。</p>',table(pd.DataFrame(version_compare)),
      '<p>预测R²以逐次留一PRESS计算，已与17次显式重拟合交叉核验；这是内部验证，不能代替新增独立实验。失拟不显著表示当前检验未检出明显失拟，不等于证明模型完全正确。</p>',
      '<h2>3. 方程、方差分析与诊断</h2><div class="eq">编码A=(温度−85)/10；B=(相比−1)/0.333；C=(初始氟含量−1)/0.2</div>',
      '<div class="eq">氟萃取率/% = '+html.escape(equation(mf,'quadratic'))+'</div><div class="eq">磷萃取率/% = '+html.escape(equation(mp,'linear'))+'</div>',
      '<p>实际因素方程以及完整系数、单项偏F检验和区间见结果Excel。实际方程中的初始氟含量按数值1表示1%，不能改成0.01后继续使用原系数。</p>',table(pd.DataFrame(anova)),
      *[image(p) for p in images[:3]],'<p>诊断图标题现同时显示拟合R²、调整R²和预测R²。实测与拟合散点来自参与建模的实验，不能当作独立验证图；±3虚线仅为核查参考，不是自动删点标准。</p>',
      *[image(p) for p in images[3:5]],
      '<h2>4. 重复工况与折中优化</h2>',image(images[-1]),
      f'<p>单次等权得分最高为运行{int(single_best.Run)}（F={single_best.F:.4f}%，P={single_best.P:.5f}%），它是5次中心重复中的一次。中心工况均值为F={centre.F_mean:.6f}%、P={centre.P_mean:.6f}%，样本标准差分别为{centre.F_SD:.6f}和{centre.P_SD:.6f}个百分点。应合并重复工况比较，不能挑选其中一次作为工况均值。</p>',
      f'<p>各工况先平均响应再计算等权D后，已测工况中最高为温度{group_best.Temperature:g}°C、相比{group_best.Ratio:g}、初始氟含量{group_best.Initial_F:g}%（运行{group_best.Runs}，仅{int(group_best.n)}次）。它仍需独立重复确认。</p>',table(group),
      '<p>沿用用户目标，同时提高F、降低P；两者等权。D=√(dF·dP)，dF=clip[(F−Fmin)/(Fmax−Fmin),0,1]，dP=clip[(Pmax−P)/(Pmax−Pmin),0,1]。极值取本版17次观测范围；实测排名代入实测值，寻优代入模型预测。</p>',
      f'<div class="card"><b>待验证折中候选：</b>温度{rr["温度/°C"]:.1f}°C、相比{rr["相比"]:.3f}、初始氟含量{rr["初始氟含量/%"]:.3f}%。预测氟萃取率{rr["氟预测/%"]:.2f}%，磷萃取率{rr["磷预测/%"]:.2f}%。这是模型候选，尚未证明优于现有工况。</div>',table(cand),
      '<p>搜索采用氟完整二次及磷线性模型，限制各因素编码[−1,1]且|A|+|B|+|C|≤2，保持在BBD实际设计点凸包内；网格与多起点连续搜索交叉核验。候选接近设计边界，建议与运行9工况和中心工况各进行至少3次独立全流程重复比较。</p>',
      '<p>CI为固定条件下均值95%置信区间，PI为一次新实验95%预测区间，均未包含选模、寻优、系统测量和截图舍入误差。新的验证应保留浓度、相体积和仪器记录；高R²本身不能替代这些证据。</p>',
      '<h2>5. 文件与复现</h2><p>文件包包含14页结果工作簿、六张图、截图转录CSV、旧版响应对照CSV、导入CSV、分析脚本和版本依赖。原Excel及原报告未覆盖。运行脚本可重建本版结果；本计算使用Python常规响应面方法，未运行专有Design-Expert软件。</p>',
      '<p class="small">截图转录CSV SHA256：'+source_sha+'</p></main></html>']
    (out/'report.html').write_text('\n'.join(parts),encoding='utf-8')
    (out/'requirements.txt').write_text('\n'.join(f'{n}=={importlib.metadata.version(n)}' for n in ['numpy','pandas','scipy','statsmodels','matplotlib','openpyxl'])+'\n',encoding='utf-8')
    if Path(__file__).resolve()!=out/'analyze_update.py':shutil.copy2(__file__,out/'analyze_update.py')
    (out/'reproduce.txt').write_text('Python 3.12；安装requirements.txt依赖。\n运行：python analyze_update.py source_screenshot_values.csv --previous previous_version_values.csv --output reproduced_results\n来源为用户确认的正式更正截图，仅含显示精度。原数据不覆盖。\n',encoding='utf-8')
    assert hashlib.sha256(source.read_bytes()).hexdigest()==source_sha
    check=load_workbook(out/'results.xlsx',data_only=True);assert len(check.sheetnames)==14 and check['截图数据及编码'].max_row==18
    # Source/hash and numeric outputs are checked again before packaging.
    (out/'SHA256SUMS.txt').write_text('\n'.join(hashlib.sha256(p.read_bytes()).hexdigest()+'  '+str(p.relative_to(out)) for p in sorted(out.rglob('*')) if p.is_file() and p.name!='SHA256SUMS.txt')+'\n',encoding='utf-8')
    archive=out.parent/(out.name+'.zip')
    with zipfile.ZipFile(archive,'w',zipfile.ZIP_DEFLATED) as zz:
        for p in sorted(out.rglob('*')):
            if p.is_file():zz.write(p,out.name+'/'+str(p.relative_to(out)))
    with zipfile.ZipFile(archive) as zz:assert zz.testzip() is None
    print(key_summary.to_string(index=False));print('\nCANDIDATES\n'+cand.to_string(index=False));print('\nBEST_GROUP\n'+group_best.to_string());print('\nOUTPUT',out,'ARCHIVE',archive)

if __name__=='__main__':main()
