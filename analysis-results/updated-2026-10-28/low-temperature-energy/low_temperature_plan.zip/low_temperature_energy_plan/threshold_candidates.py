from pathlib import Path
import json
import numpy as np
import pandas as pd
from scipy import stats,optimize

folder=Path(__file__).resolve().parent
d=pd.read_csv(Path(__file__).resolve().parent/'source_data.csv')
a=(d.Temperature.to_numpy()-85)/10;b=(d.Ratio.to_numpy()-1)/.333;c=(d.Initial_F.to_numpy()-1)/.2
x=np.column_stack([np.ones(len(a)),a,b,c,a*b,a*c,b*c,a*a,b*b,c*c])
models={}
for name,xx,y in [('F',x,d.F.to_numpy()),('P',x[:,:4],d.P.to_numpy())]:
    co=np.linalg.lstsq(xx,y,rcond=None)[0];e=y-xx@co;df=len(y)-xx.shape[1];mse=float(e@e/df)
    models[name]=(co,np.linalg.inv(xx.T@xx),mse,df)

def row(v):
    aa,bb,cc=np.atleast_2d(v).T
    return np.column_stack([np.ones(len(aa)),aa,bb,cc,aa*bb,aa*cc,bb*cc,aa*aa,bb*bb,cc*cc])

def calc(v):
    z=row(v);out={}
    for name,(co,inv,mse,df) in models.items():
        zz=z[:,:len(co)];mu=zz@co;h=np.einsum('ij,jk,ik->i',zz,inv,zz);q=stats.t.ppf(.975,df)
        out[name+'_mean']=mu;out[name+'_CI_low']=mu-q*np.sqrt(mse*h);out[name+'_CI_high']=mu+q*np.sqrt(mse*h)
        out[name+'_PI_low']=mu-q*np.sqrt(mse*(1+h));out[name+'_PI_high']=mu+q*np.sqrt(mse*(1+h))
    return out

def bounds_value(v,mode):
    p=calc(v)
    return p['F_mean' if mode=='point' else 'F_'+mode+'_low'],p['P_mean' if mode=='point' else 'P_'+mode+'_high']

def cvals(v,mode):
    f,p=bounds_value(v,mode)
    return np.array([float(f[0]-80),float(5-p[0]),2-np.abs(v).sum()])

def record(v,mode):
    p=calc(v);out={k:float(val[0]) for k,val in p.items()}
    out.update({'coded':list(map(float,v)),'temperature':float(85+10*v[0]),'ratio':float(1+.333*v[1]),'initial_F':float(1+.2*v[2]),'coded_L1':float(np.abs(v).sum()),'margins':cvals(v,mode).tolist()})
    return out

axis=np.linspace(-1,1,41);grid=np.array(np.meshgrid(axis,axis,axis,indexing='ij')).reshape(3,-1).T;grid=grid[np.abs(grid).sum(axis=1)<=2+1e-12]
rng=np.random.default_rng(20261028)
output={}
for mode in ['point','CI','PI']:
    ff,pp=bounds_value(grid,mode);violation=np.maximum.reduce([80-ff,pp-5,np.zeros(len(grid))]);idx=np.argsort(violation)[:20]
    seeds=np.vstack([grid[idx],np.zeros((1,3)),rng.uniform(-1,1,(20,3))]);mm=[]
    for s in seeds:
        slack=max(0,float(80-bounds_value(s,mode)[0][0]),float(bounds_value(s,mode)[1][0]-5))+.01
        r=optimize.minimize(lambda u:u[3],np.r_[s,slack],method='SLSQP',bounds=[(-1,1)]*3+[(0,30)],constraints=[{'type':'ineq','fun':lambda u:np.r_[cvals(u[:3],mode)[:2]+u[3],cvals(u[:3],mode)[2]]}],options={'ftol':1e-12,'maxiter':1500})
        if r.success:mm.append(r)
    minimum_violation=min(mm,key=lambda r:r.fun)
    info={'minimum_common_pp_violation':float(minimum_violation.fun),'minimax_point':record(minimum_violation.x[:3],mode)}
    feas=(ff>=80-1e-8)&(pp<=5+1e-8)
    valid_grid=grid[feas];starts=[]
    if len(valid_grid):
        starts.extend(valid_grid[np.argsort(valid_grid[:,0])[:30]])
    starts.extend([r.x[:3] for r in mm if r.fun<1e-6])
    if not starts:
        info['feasible']=False;output[mode]=info;print(mode,json.dumps(info,ensure_ascii=False));continue
    solutions=[]
    for s in starts:
        r=optimize.minimize(lambda v:v[0],s,method='SLSQP',bounds=[(-1,1)]*3,constraints=[{'type':'ineq','fun':lambda v:cvals(v,mode)}],options={'ftol':1e-12,'maxiter':1500})
        if r.success and np.min(cvals(r.x,mode))>=-1e-6:solutions.append(r)
    if not solutions:
        info['feasible']=False;info['note']='minimization did not converge to a verified feasible point';output[mode]=info;print(mode,json.dumps(info));continue
    best=min(solutions,key=lambda r:r.fun);aa=max(-1,min(1,float(best.x[0])+2e-8));bc_seeds=[r.x[1:] for r in solutions if r.x[0]<=best.x[0]+1e-5]+[best.x[1:]]
    secondary=[]
    for s in bc_seeds:
        r=optimize.minimize(lambda bc:-float(calc([aa,*bc])['F_mean'][0]),s,method='SLSQP',bounds=[(-1,1)]*2,constraints=[{'type':'ineq','fun':lambda bc:cvals([aa,*bc],mode)}],options={'ftol':1e-12,'maxiter':1500})
        if r.success and np.min(cvals([aa,*r.x],mode))>=-1e-6:secondary.append(r)
    rr=min(secondary,key=lambda r:r.fun);best_v=np.r_[aa,rr.x]
    info.update({'feasible':True,'minimum_temperature':85+10*best.x[0],'lexicographic_candidate':record(best_v,mode),'successful_primary_starts':len(solutions)})
    # Search implementable 0.1°C / .001 ratio / .001 %-content lattice, never relax constraints.
    minimum_t=np.ceil((85+10*best.x[0]-1e-7)*10)/10
    b0=1+.333*best_v[1];c0=1+.2*best_v[2];rounded=None
    for tt in np.arange(minimum_t,95.00001,.1):
        bb=np.arange(max(.667,round(b0,3)-.030),min(1.333,round(b0,3)+.030)+.0005,.001)
        cc=np.arange(max(.8,round(c0,3)-.030),min(1.2,round(c0,3)+.030)+.0005,.001)
        bc=np.array(np.meshgrid(bb,cc,indexing='ij')).reshape(2,-1).T
        vv=np.column_stack([np.full(len(bc),(tt-85)/10),(bc[:,0]-1)/.333,(bc[:,1]-1)/.2])
        fv,pv=bounds_value(vv,mode);ok=(fv>=80)&(pv<=5)&(np.abs(vv).sum(axis=1)<=2+1e-10)
        if np.any(ok):
            valid=vv[ok];j=int(np.argmax(calc(valid)['F_mean']));rounded=record(valid[j],mode);break
    info['rounded_candidate']=rounded
    output[mode]=info;print(mode,json.dumps(info,ensure_ascii=False))

easy=[]
for rr in [.80,.82,.83,.84,.85,.86,.88,.90]:
    vv=np.array([-1,(rr-1)/.333,0.])
    dd=record(vv,'point');dd['point_feasible']=bool(np.min(cvals(vv,'point'))>=0);dd['CI_feasible']=bool(np.min(cvals(vv,'CI'))>=0);dd['PI_feasible']=bool(np.min(cvals(vv,'PI'))>=0);easy.append(dd)
output['fixed_initial_F_1_percent_75C']=easy
output['scope']='Minimum temperature is only a temperature proxy; no actual kWh measured. Marginal 95% CI/PI are separate per response, not joint guarantee. Fixed-model intervals exclude model-selection/data-source/optimization uncertainty.'
(folder/'threshold_candidates.json').write_text(json.dumps(output,ensure_ascii=False,indent=2),encoding='utf-8')
print('EASY',json.dumps(easy,ensure_ascii=False))
