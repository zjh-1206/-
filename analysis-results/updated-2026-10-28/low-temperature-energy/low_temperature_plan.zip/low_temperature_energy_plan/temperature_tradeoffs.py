from pathlib import Path
import json
import numpy as np
import pandas as pd
import statsmodels.api as sm
from scipy.optimize import minimize

root=Path(__file__).resolve().parent
root.mkdir(exist_ok=True)
d=pd.read_csv(Path(__file__).resolve().parent/'source_data.csv')
d['A']=(d.Temperature-85)/10;d['B']=(d.Ratio-1)/.333;d['C']=(d.Initial_F-1)/.2

def design(x,kind='quadratic'):
    a,b,c=np.atleast_2d(x).T
    z=np.column_stack([np.ones(len(a)),a,b,c,a*b,a*c,b*c,a*a,b*b,c*c])
    return z if kind=='quadratic' else z[:,:4]

x=d[['A','B','C']].to_numpy()
mf=sm.OLS(d.F,design(x)).fit();mp=sm.OLS(d.P,design(x,'linear')).fit()
fmin,fmax=d.F.min(),d.F.max();pmin,pmax=d.P.min(),d.P.max()

def score(ff,pp):return np.sqrt(np.clip((ff-fmin)/(fmax-fmin),0,1)*np.clip((pmax-pp)/(pmax-pmin),0,1))

fixed=[];optimum=[]
for T in [75,85,95]:
    A=(T-85)/10
    z=np.array([A,0,0])
    pf=mf.get_prediction(design(z)).summary_frame().iloc[0]
    pp=mp.get_prediction(design(z,'linear')).summary_frame().iloc[0]
    fixed.append({'T_degC':T,'ratio':1.,'initial_F_percent':1.,
        'F_prediction':dict(pf),'P_prediction':dict(pp),
        'status':'five replicated observations at this condition' if T==85 else 'model interpolation; no observation at this exact condition'})
    axis=np.linspace(-1,1,161)
    bc=np.array(np.meshgrid(axis,axis,indexing='ij')).reshape(2,-1).T
    bc=bc[np.abs(bc).sum(axis=1)<=2-abs(A)+1e-10]
    def pred(bc):
        bc=np.atleast_2d(bc);xx=np.column_stack([np.full(len(bc),A),bc]);return design(xx)@mf.params.to_numpy(),design(xx,'linear')@mp.params.to_numpy()
    def D(bc):return score(*pred(bc))
    ds=D(bc);starts=bc[np.argsort(ds)[-20:]]
    solutions=[]
    for start in np.vstack([starts,[[0,0]]]):
        r=minimize(lambda v:-D(v)[0],start,method='SLSQP',bounds=[(-1,1),(-1,1)],constraints=[{'type':'ineq','fun':lambda v:2-abs(A)-np.abs(v).sum()}],options={'maxiter':600,'ftol':1e-13})
        if r.success and abs(A)+np.abs(r.x).sum()<=2+1e-7:solutions.append(r)
    r=min(solutions,key=lambda s:s.fun);b,c=r.x
    ff,pp=pred(r.x)
    assert -r.fun>=float(ds.max())-1e-7
    optimum.append({'T_degC':T,'ratio':1+.333*b,'initial_F_percent':1+.2*c,'F_pred_percent':float(ff[0]),'P_pred_percent':float(pp[0]),'D':float(-r.fun),'coded':[A,float(b),float(c)],'coded_L1':float(abs(A)+abs(b)+abs(c)),'grid_best_D':float(ds.max())})

group=d.groupby(['Temperature','Ratio','Initial_F'],as_index=False).agg(n=('Run','count'),Runs=('Run',lambda s:','.join(map(str,s))),F=('F','mean'),P=('P','mean'),F_SD=('F','std'),P_SD=('P','std'),beta_mean=('beta','mean'))
group['D']=score(group.F,group.P)
actual=[]
for T,g in group.groupby('Temperature'):
    pareto=[]
    for i,row in g.iterrows():
        dominates=(g.F>=row.F)&(g.P<=row.P)&((g.F>row.F)|(g.P<row.P))
        if not dominates.any():pareto.append(i)
    actual.append({'T_degC':int(T),'best_D_condition':g.loc[g.D.idxmax()].to_dict(),'within_T_Pareto':g.loc[pareto].to_dict('records')})

payload={'assumptions':{'F_model':'full quadratic','P_model':'linear; minimize P as previously agreed unless user changes goal','energy':'Not measured or estimated here; temperature only, no kWh inference','normalization':{'Fmin':float(fmin),'Fmax':float(fmax),'Pmin':float(pmin),'Pmax':float(pmax)},'temperature_bounds':'75-95 degC; all candidates satisfy BBD convex hull'},'fixed_ratio1_initialF1':fixed,'temperature_conditional_D_optima':optimum,'observed_temperature_comparison':actual,'center_group':group[group.n==5].to_dict('records')}
def safe(o):
    if isinstance(o,dict):return {k:safe(v) for k,v in o.items()}
    if isinstance(o,(list,tuple)):return [safe(v) for v in o]
    if isinstance(o,(float,np.floating)) and not np.isfinite(o):return None
    return o
(root/'temperature_tradeoffs.json').write_text(json.dumps(safe(payload),ensure_ascii=False,indent=2,allow_nan=False),encoding='utf-8')
print('FIXED CONDITIONS')
for r in fixed:print(r)
print('CONDITIONAL OPTIMA')
for r in optimum:print(r)
print('OBSERVED BEST PER TEMPERATURE')
for r in actual:print(r['T_degC'],r['best_D_condition'])
