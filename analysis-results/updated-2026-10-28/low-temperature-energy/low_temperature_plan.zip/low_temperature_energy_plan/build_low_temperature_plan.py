#!/usr/bin/env python3
"""Low-temperature screening with F>=80%, P<=5%; no energy measurements."""
import argparse,base64,hashlib,html,importlib.metadata,json,os,shutil,tempfile,zipfile
from pathlib import Path
os.environ.setdefault('MPLCONFIGDIR',str(Path(tempfile.gettempdir())/'response_surface_mplconfig'))
import numpy as np
import pandas as pd
import statsmodels.api as sm
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib import font_manager
from openpyxl import load_workbook
from openpyxl.styles import Font,PatternFill,Alignment
from openpyxl.utils import get_column_letter
from openpyxl.workbook.properties import CalcProperties

def design(x):
    a,b,c=np.atleast_2d(x).T
    return np.column_stack([np.ones(len(a)),a,b,c,a*b,a*c,b*c,a*a,b*b,c*c])

def main():
    ap=argparse.ArgumentParser();ap.add_argument('data');ap.add_argument('thresholds');ap.add_argument('temperature_comparison');ap.add_argument('--output',required=True);args=ap.parse_args()
    out=Path(args.output);out.mkdir(parents=True,exist_ok=True)
    d=pd.read_csv(args.data);threshold=json.loads(Path(args.thresholds).read_text());comparison=json.loads(Path(args.temperature_comparison).read_text())
    x=np.column_stack([(d.Temperature-85)/10,(d.Ratio-1)/.333,(d.Initial_F-1)/.2]);z=design(x)
    mf=sm.OLS(d.F,z).fit();mp=sm.OLS(d.P,z[:,:4]).fit()
    def predict(name,t,r,c):
        xx=np.array([(t-85)/10,(r-1)/.333,(c-1)/.2]);zz=design(xx)
        assert np.max(np.abs(xx))<=1+1e-9 and np.abs(xx).sum()<=2+1e-8
        pf=mf.get_prediction(zz).summary_frame().iloc[0];pp=mp.get_prediction(zz[:,:4]).summary_frame().iloc[0]
        row={'方案':name,'温度/°C':t,'相比':r,'初始氟含量/%':c,'氟预测/%':pf['mean'],'磷损失预测/%':pp['mean'],
           '氟均值CI下限':pf['mean_ci_lower'],'氟均值CI上限':pf['mean_ci_upper'],'氟单次PI下限':pf['obs_ci_lower'],'氟单次PI上限':pf['obs_ci_upper'],
           '磷均值CI下限':pp['mean_ci_lower'],'磷均值CI上限':pp['mean_ci_upper'],'磷单次PI下限':pp['obs_ci_lower'],'磷单次PI上限':pp['obs_ci_upper']}
        row['点预测达标']=bool(pf['mean']>=80-1e-8 and pp['mean']<=5+1e-8)
        row['均值CI界达标']=bool(pf['mean_ci_lower']>=80-1e-8 and pp['mean_ci_upper']<=5+1e-8)
        row['单次PI界达标']=bool(pf['obs_ci_lower']>=80-1e-8 and pp['obs_ci_upper']<=5+1e-8)
        return row
    candidates=[]
    for key,title in [('point','点预测约束最低温候选'),('CI','均值CI约束最低温候选'),('PI','单次PI约束边界候选')]:
        q=threshold[key]['rounded_candidate'];row=predict(title,q['temperature'],q['ratio'],q['initial_F'])
        assert np.isclose(row['氟预测/%'],q['F_mean'],atol=1e-8) and np.isclose(row['磷损失预测/%'],q['P_mean'],atol=1e-8)
        candidates.append(row)
    candidates.extend([predict('低温验证A',75,.830,1),predict('保守验证B',90,.770,1)])
    cf=pd.DataFrame(candidates);fixed=pd.DataFrame([predict('相比1的条件预测',t,1,c) for c in [1,1.2] for t in [75,80,85,90,95]])
    source_notes=[('用户目标','考虑能耗，提高氟萃取率并降低磷损失；氟萃取率至少80%，磷损失最多5%。暂无能耗数据，用户要求先比较低温方案。'),
      ('边界','温度75–95°C、相比0.667–1.333、初始氟0.8–1.2%；编码绝对值和≤2，保持在原BBD设计点凸包内。不外推低于75°C。'),
      ('能耗状态','未测量或估计任何kWh。最低温候选只用于筛选，不能称为实际能耗最低。相比改变会影响相体积和热负荷，实际必须按同一处理量比较。'),
      ('数据与模型','采用用户确认的正式更正截图数据及显示精度。氟完整二次、磷线性；β不用于可靠寻优。'),
      ('优化规则','先最低温度，再在该温度下最大化氟预测值；分别以点预测、均值95%CI界、单次95%PI界约束F≥80、P≤5。三种约束解释不同。'),
      ('平均与单次','均值CI描述同条件下平均响应的不确定性，单次PI描述下一次实验波动。均值达标不保证每个批次达标。'),
      ('区间限制','各响应为固定模型点位的边际95%区间；不等于批次质量保证，未计入选模、寻优、测量系统、截图舍入与放大误差。'),
      ('推荐比较','A：75°C/相比0.830/初始氟1%；B：90°C/相比0.770/初始氟1%。各至少3次独立全流程重复，并实测同一边界内的总耗电与进料量。'),
      ('控制条件','两方案初始氟相同。记录并尽量统一起始温度、处理进料量、保温/萃取时长和搅拌强度；记录两相实际体积，相比方向需确认。'),
      ('能耗指标','单位处理量能耗=本批总耗电(kWh)/进料水相体积(m³)；单位回收氟能耗=总耗电/实测回收氟质量(kg)。模板采用实测进料氟浓度，不能把因素百分含量直接当kg/m³。'),
      ('模板说明','能耗记录页为未来试验计划，实测响应和能耗均留空。计算列仅在所需实测输入齐全时显示；不将旧版响应配到新批次能耗。'),
      ('公平计量','总耗电应覆盖统一约定的加热、保温、搅拌等本批过程；若包括再生/冷却/泵送，应对所有方案采用一致范围。额定功率×时间仅是估算，不能替代真实平均功率或电表积分。')]
    planned=[]
    for t,r,prefix in [(75,.830,'A'),(90,.770,'B')]:
        for rep in [1,2,3]:planned.append([f'{prefix}-{rep}',rep,t,r,1,None,None,None,None,None,None,None,None,None,None,None,None])
    columns=['计划编号','重复','温度/°C','相比','初始氟含量/%','起始温度/°C','进料水相体积/L','本批实测氟萃取率/%','本批实测磷损失/%','本批总耗电/kWh','总运行时间/min','实测进料氟浓度/kg·m⁻³','单位处理量能耗/kWh·m⁻³','单位回收氟能耗/kWh·kg⁻¹','本批质量判定','保温或萃取时间/min','搅拌转速/rpm']
    template=pd.DataFrame(planned,columns=columns)
    with pd.ExcelWriter(out/'low_temperature_plan.xlsx',engine='openpyxl') as writer:
        for name,df in [('说明',pd.DataFrame(source_notes,columns=['项目','说明'])),('候选与区间',cf),('同相比同浓度温度比较',fixed),('能耗记录模板',template),('正式更正数据',d)]:
            df.to_excel(writer,sheet_name=name,index=False);s=writer.book[name];s.freeze_panes='A2';s.auto_filter.ref=s.dimensions
            for cell in s[1]:cell.fill=PatternFill('solid',fgColor='183C50');cell.font=Font(color='FFFFFF',bold=True)
            for row in s.iter_rows(min_row=2):
                for cell in row:
                    cell.alignment=Alignment(vertical='top',wrap_text=True)
                    if isinstance(cell.value,float):cell.number_format='0.000000'
            for col in s.columns:s.column_dimensions[get_column_letter(col[0].column)].width=min(45,max(13,max(len(str(c.value or '')) for c in col)*1.15))
            if name=='说明':s.column_dimensions['B'].width=112
        s=writer.book['能耗记录模板']
        for row in range(2,8):
            s.cell(row,13,f'=IF(AND(ISNUMBER(J{row}),ISNUMBER(G{row}),G{row}>0),J{row}/(G{row}/1000),"")')
            s.cell(row,14,f'=IF(AND(ISNUMBER(J{row}),ISNUMBER(G{row}),ISNUMBER(L{row}),ISNUMBER(H{row}),G{row}>0,L{row}>0,H{row}>0),J{row}/((G{row}/1000)*L{row}*(H{row}/100)),"")')
            s.cell(row,15,f'=IF(AND(ISNUMBER(H{row}),ISNUMBER(I{row})),IF(AND(H{row}>=80,I{row}<=5),"达标","未达标"),"")')
            for col in [6,7,8,9,10,11,12,16,17]:s.cell(row,col).fill=PatternFill('solid',fgColor='FFF4CC')
        writer.book.calculation=CalcProperties(fullCalcOnLoad=True)
    fp=Path('/usr/share/fonts/opentype/noto/NotoSansCJK-Regular.ttc')
    if fp.exists():font_manager.fontManager.addfont(str(fp));plt.rcParams['font.family']=font_manager.FontProperties(fname=str(fp)).get_name()
    plt.rcParams.update({'axes.unicode_minus':False,'font.size':10,'savefig.dpi':180})
    selected=cf.iloc[[3,2,4]].copy();fig,axs=plt.subplots(1,2,figsize=(12,5),layout='constrained')
    for ax,tag,target in [(axs[0],'氟',80),(axs[1],'磷',5)]:
        yy=np.arange(3);means=selected['氟预测/%' if tag=='氟' else '磷损失预测/%'].to_numpy();lo=selected[tag+'单次PI下限'].to_numpy();hi=selected[tag+'单次PI上限'].to_numpy()
        clo=selected[tag+'均值CI下限'].to_numpy();chi=selected[tag+'均值CI上限'].to_numpy()
        ax.errorbar(means,yy,xerr=[means-lo,hi-means],fmt='o',color='#187b8c',capsize=5,label='单次95%PI');ax.hlines(yy,clo,chi,color='#187b8c',linewidth=6,label='均值95%CI')
        ax.axvline(target,color='#c77439',ls='--',label='用户阈值');ax.set_yticks(yy,[f'{r["温度/°C"]:g}°C / 相比{r["相比"]:.3f}\n初始氟{r["初始氟含量/%"]:.3f}%' for _,r in selected.iterrows()]);ax.invert_yaxis();ax.set(xlabel=tag+'萃取率/%',title=('氟至少80%' if tag=='氟' else '磷损失最多5%'));ax.grid(axis='x',alpha=.2);ax.legend(fontsize=8)
    fig.suptitle('低温候选的均值与单次实验不确定性｜均为模型预测，尚未验证',fontsize=13);fig.savefig(out/'candidate_intervals.png');plt.close(fig)
    def table(df):return df.to_html(index=False,border=0,float_format=lambda v:f'{v:.6g}',na_rep='—')
    def embed(path):return '<img src="data:image/png;base64,'+base64.b64encode(path.read_bytes()).decode()+'" alt="候选预测区间">'
    summary=cf[['方案','温度/°C','相比','初始氟含量/%','氟预测/%','磷损失预测/%','均值CI界达标','单次PI界达标']]
    css='body{font:16px/1.8 system-ui,"Microsoft YaHei",sans-serif;color:#203c49;background:#f4f7f8;margin:0}main{max-width:1100px;margin:auto;padding:40px;background:white}h2{margin-top:32px;border-bottom:2px solid #d8e4e8}table{border-collapse:collapse;display:block;overflow:auto;width:100%;font-size:13px}th,td{white-space:nowrap;text-align:left;padding:9px 12px;border-bottom:1px solid #dce6e9}th{background:#e7f0f3}img{width:100%}.card{background:#edf6f7;padding:18px}.note{background:#fff5df;border-left:4px solid #c48d30;padding:16px}@media print{main{padding:0}}'
    parts=['<!doctype html><html lang="zh-CN"><meta charset="utf-8"><title>能耗与萃取效率：低温候选比较</title><style>'+css+'</style><main><h1>能耗与萃取效率：低温候选比较</h1>',
      '<div class="card"><b>用户目标：</b>氟萃取率≥80%，磷损失≤5%。暂无耗电数据，先以降低温度筛选方案；真实单位能耗尚未比较。</div>',
      '<h2>1. 可优先验证的两个方案</h2>',table(summary.iloc[[3,4]]),
      '<p>A：75°C、相比0.830、初始氟1%，模型预测F≈80.98%、P≈3.99%。两响应均值区间达标，但单次PI会跨出80%/5%要求，属于有批次风险的低温试验点。</p>',
      '<p>B：90°C、相比0.770、初始氟1%，模型预测F≈81.21%、P≈2.92%。当前模型的单次PI仍在阈值内，可作为更保守的验证点；这不是已经通过验证的工艺。</p>',
      embed(out/'candidate_intervals.png'),
      '<div class="note">能耗不能仅由温度确定。相比、两相体积、初始温度、保温时间及搅拌也影响耗电。A/B还改变了相比，因此需按相同进料处理量实测总耗电，才能决定能耗优势。</div>',
      '<h2>2. 数学筛选与不确定性</h2>',table(summary),
      '<p>模型点预测达标、平均响应CI达标和单次PI达标是不同要求。点预测及均值CI约束的最低温度均可到75°C；单次PI约束的数值最低温度约87.04°C。87.1°C取整候选的余量极小，因此用90°C易操作点作为对照更便于验证。最低温度以现有75–95°C范围为限，不外推更低温。</p>',table(cf),
      '<p>所有区间均为固定模型下各响应的95%区间，未包含选模、寻优、截图舍入、测量系统和放大误差；不等于单批质量保证。模型以最新正式更正数据拟合，F完整二次，P线性。</p>',
      '<h2>3. 同因素温度比较</h2>',table(fixed[['温度/°C','相比','初始氟含量/%','氟预测/%','磷损失预测/%']]),
      '<p>固定相比1时，初始F1%的85→95°C氟增益约0.6265个百分点；初始F1.2%时约1.5166个百分点，说明升温收益受初始含量影响。磷线性模型的温度差值95%区间跨0，不能将升温降低磷损失视为已证实效应。</p>',
      '<h2>4. 能耗实测与下一步</h2><p>建议A/B各至少3次独立全流程重复，记录本批真实F/P响应、起始温度、进料量、总耗电、处理时间和搅拌设置。两方案保温/萃取时间、起始条件和计量范围应一致；尽量平衡实验顺序，避免余热使后续批次看起来更省电。</p>',
      '<p>Excel黄色列为待填实测值，当前均留空。模板自动计算：单位处理量能耗=总耗电/进料体积(m³)；单位回收氟能耗=总耗电/[进料体积×实测进料氟浓度×本批氟萃取率]。百分含量不能未经密度/基准换算直接代替kg/m³浓度。</p>',
      '<p>取得数据后，先筛除不满足80%/5%要求的方案，再比较单位处理量与单位回收氟能耗。若继续在Design-Expert中优化，可新增实测单位能耗响应并设为最小化；当前仅可把温度最小化作为方案筛选代理。</p>',
      '<h2>5. 数据与复现</h2><p>文件包保留正式更正截图CSV、阈值搜索结果、温度比较结果、搜索脚本和本报告生成脚本。原报告和95°C旧候选保留；旧候选只优化F/P，未考虑本次能耗目标与80%/5%硬指标。</p></main></html>']
    (out/'report.html').write_text('\n'.join(parts),encoding='utf-8')
    for src,name in [(Path(args.data),'source_data.csv'),(Path(args.thresholds),'threshold_candidates.json'),(Path(args.temperature_comparison),'temperature_tradeoffs.json')]:
        if src.resolve()!=(out/name).resolve():shutil.copy2(src,out/name)
    if Path(__file__).resolve()!=out/'build_low_temperature_plan.py':shutil.copy2(__file__,out/'build_low_temperature_plan.py')
    (out/'requirements.txt').write_text('\n'.join(f'{n}=={importlib.metadata.version(n)}' for n in ['numpy','pandas','scipy','statsmodels','matplotlib','openpyxl'])+'\n',encoding='utf-8')
    (out/'reproduce.txt').write_text('python build_low_temperature_plan.py source_data.csv threshold_candidates.json temperature_tradeoffs.json --output reproduced\n阈值搜索结果的再生成另见包内搜索脚本；所有结果仅为低温筛选，未测kWh。\n',encoding='utf-8')
    workbook=load_workbook(out/'low_temperature_plan.xlsx');assert len(workbook.sheetnames)==5 and workbook['能耗记录模板'].max_row==7
    assert all(workbook['能耗记录模板'].cell(r,10).value is None for r in range(2,8))
    assert cf.iloc[3]['均值CI界达标'] and not cf.iloc[3]['单次PI界达标'] and cf.iloc[4]['单次PI界达标']
    print(summary.to_string(index=False));print('OUTPUT',out)

if __name__=='__main__':main()
