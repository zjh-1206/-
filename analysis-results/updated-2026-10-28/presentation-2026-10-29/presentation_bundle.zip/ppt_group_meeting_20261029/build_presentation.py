#!/usr/bin/env python3
"""Editable group-meeting slides and high-resolution figures from confirmed data."""
import os,json,hashlib,shutil,argparse,tempfile
from pathlib import Path
os.environ.setdefault('MPLCONFIGDIR',str(Path(tempfile.gettempdir())/'response_surface_ppt_mplconfig'))
import numpy as np
import pandas as pd
import statsmodels.api as sm
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib import font_manager
from pptx import Presentation
from pptx.util import Inches,Pt
from pptx.dml.color import RGBColor
from pptx.enum.text import PP_ALIGN,MSO_ANCHOR
from pptx.enum.shapes import MSO_SHAPE
from pptx.oxml.xmlchemy import OxmlElement

NAVY='183647';TEAL='157A8A';ORANGE='D48A35';GRAY='637988';LIGHT='EAF3F5';BG='F6F8FA';WHITE='FFFFFF';FONT='Noto Sans CJK SC'
def rgb(h):return RGBColor.from_string(h)
def design(x):
    a,b,c=np.atleast_2d(x).T
    return np.column_stack([np.ones(len(a)),a,b,c,a*b,a*c,b*c,a*a,b*b,c*c])

def main():
    ap=argparse.ArgumentParser();ap.add_argument('--data',required=True);ap.add_argument('--output',required=True);ap.add_argument('--energy-plot',required=True);args=ap.parse_args()
    out=Path(args.output);out.mkdir(parents=True,exist_ok=True);assets=out/'figures';assets.mkdir(exist_ok=True)
    d=pd.read_csv(args.data);x=np.column_stack([(d.Temperature-85)/10,(d.Ratio-1)/.333,(d.Initial_F-1)/.2]);z=design(x)
    mf=sm.OLS(d.F,z).fit();mp=sm.OLS(d.P,z[:,:4]).fit();mb=sm.OLS(d.beta,z).fit()
    font_path='/usr/share/fonts/opentype/noto/NotoSansCJK-Regular.ttc'
    if Path(font_path).exists():font_manager.fontManager.addfont(font_path);plt.rcParams['font.family']=font_manager.FontProperties(fname=font_path).get_name()
    plt.rcParams.update({'font.size':16,'axes.labelsize':17,'axes.titlesize':19,'xtick.labelsize':14,'ytick.labelsize':14,'legend.fontsize':12,'axes.unicode_minus':False,'axes.spines.top':False,'axes.spines.right':False,'savefig.dpi':200})
    # 1. Actual BBD points, repeated centre aggregated only for design illustration.
    fig=plt.figure(figsize=(6.7,4.5),layout='constrained');ax=fig.add_subplot(111,projection='3d')
    unique=np.unique(x,axis=0);edge=np.any(abs(unique)>1e-8,axis=1)
    ax.scatter(*unique[edge].T,color='#'+TEAL,s=90,depthshade=False);ax.scatter(0,0,0,s=240,color='#'+ORANGE,depthshade=False)
    for i in [-1,1]:
        for j in [-1,1]:
            ax.plot([-1,1],[i,i],[j,j],color='#c4d3da',lw=.8);ax.plot([i,i],[-1,1],[j,j],color='#c4d3da',lw=.8);ax.plot([i,i],[j,j],[-1,1],color='#c4d3da',lw=.8)
    ax.text(0,0,.17,'中心重复×5',fontsize=14,color='#'+ORANGE);ax.set(xlabel='A 温度（编码）',ylabel='B 相比（编码）',zlabel='C 初始氟（编码）');ax.set_xticks([-1,0,1]);ax.set_yticks([-1,0,1]);ax.set_zticks([-1,0,1]);ax.view_init(23,-130);fig.savefig(assets/'design.png');plt.close(fig)
    # 2. Observed F/P tradeoff, explicitly distinguishing repeated centre and mean.
    fig,ax=plt.subplots(figsize=(7,4.6),layout='constrained');ax.axvspan(0,5,ymin=(80-75)/(91-75),ymax=1,color='#dceee5',alpha=.65)
    dots=ax.scatter(d.P,d.F,c=d.beta,cmap='viridis',s=95,edgecolors='white',linewidths=.8,zorder=3)
    ax.axvline(5,color='#'+ORANGE,ls='--',lw=1.7);ax.axhline(80,color='#'+ORANGE,ls='--',lw=1.7)
    centre=d[(d.Temperature==85)&(d.Ratio==1)&(d.Initial_F==1)]
    ax.scatter(centre.P.mean(),centre.F.mean(),marker='D',s=125,facecolors='none',edgecolors='#'+NAVY,lw=1.8,zorder=4)
    ax.annotate('中心工况均值\n（5次重复）',(centre.P.mean(),centre.F.mean()),xytext=(6.2,82.1),arrowprops={'arrowstyle':'-','color':'#'+GRAY},fontsize=13)
    r=d[d.Run==12].iloc[0];ax.annotate('Run12：β最高\nF仍低于80%',(r.P,r.F),xytext=(.6,75.65),arrowprops={'arrowstyle':'-','color':'#'+GRAY},fontsize=13)
    ax.text(.4,89.8,'双阈值区域',color='#386b53',fontsize=14);ax.set(xlim=(0,11),ylim=(75,91),xlabel='磷萃取率 / %（作为磷损失指标）',ylabel='氟萃取率 / %')
    cb=fig.colorbar(dots,ax=ax,pad=.025);cb.set_label('实测β（无量纲）',fontsize=13);fig.savefig(assets/'observed_tradeoff.png');plt.close(fig)
    # 3. Centre repeat strip plot; values are observations, not model predictions.
    fig,ax=plt.subplots(figsize=(4.1,4.6),layout='constrained');xx=np.arange(len(centre));ax.scatter(xx,centre.P,s=105,color='#'+TEAL,zorder=3)
    ax.axhline(5,color='#'+ORANGE,ls='--',label='磷损失上限5%');ax.axhline(centre.P.mean(),color='#'+NAVY,lw=1.6,label='5次均值5.067%')
    ax.set_xticks(xx,['2','3','11','13','17']);ax.set(xlabel='Run运行号',ylabel='中心工况磷萃取率 / %',ylim=(4,6));ax.legend(loc='upper right',fontsize=11);ax.grid(axis='y',alpha=.2);fig.savefig(assets/'centre_repeats.png');plt.close(fig)
    # 4. T/ratio surface and predicted feasible region at fixed initial F=1%.
    t=np.linspace(75,95,90);r=np.linspace(.667,1.333,100);tt,rr=np.meshgrid(t,r);xx=np.column_stack([(tt.ravel()-85)/10,(rr.ravel()-1)/.333,np.zeros(tt.size)])
    ff=(design(xx)@mf.params).reshape(tt.shape);pp=(design(xx)[:,:4]@mp.params).reshape(tt.shape)
    fig=plt.figure(figsize=(6.1,4.7),layout='constrained');ax=fig.add_subplot(111,projection='3d');ax.plot_surface(tt,rr,ff,cmap='viridis',alpha=.96,linewidth=0);ax.set(xlabel='温度 / °C',ylabel='相比',zlabel='氟萃取率 / %');ax.view_init(25,-135);fig.savefig(assets/'F_surface.png');plt.close(fig)
    fig,ax=plt.subplots(figsize=(6.1,4.7),layout='constrained');cs=ax.contourf(tt,rr,ff,12,cmap='viridis');fig.colorbar(cs,ax=ax,label='氟预测 / %')
    ax.contour(tt,rr,ff,levels=[80],colors=['white'],linewidths=2);ax.contour(tt,rr,pp,levels=[5],colors=['#'+ORANGE],linewidths=2.3)
    feasible=(ff>=80)&(pp<=5);ax.contourf(tt,rr,feasible.astype(float),levels=[.5,1.5],colors='none',hatches=['///'])
    ax.scatter([75,90],[.830,.770],s=90,marker='*',color='white',edgecolors='#'+NAVY,zorder=5)
    ax.annotate('A',(75,.830),xytext=(76,.85),color='white',fontsize=14);ax.annotate('B',(90,.770),xytext=(90.8,.79),color='white',fontsize=14)
    ax.set(xlabel='温度 / °C',ylabel='相比');fig.savefig(assets/'feasible_contour.png');plt.close(fig)
    # 5. Beta diagnostics and influence. None of these points is labelled confirmed error.
    inf=mb.get_influence();loo=mb.resid.to_numpy()/(1-inf.hat_matrix_diag);share=100*loo**2/np.sum(loo**2);d['PRESS_share']=share
    fig,ax=plt.subplots(figsize=(6.2,4.5),layout='constrained');ax.scatter(d.beta,mb.fittedvalues,s=95,color='#'+TEAL,edgecolors='white');ax.plot([30,320],[30,320],'--',color='#'+ORANGE)
    for run in [6,8,12]:
        i=d.index[d.Run==run][0];ax.annotate(str(run),(d.loc[i,'beta'],mb.fittedvalues.iloc[i]),xytext=(5,5),textcoords='offset points',fontsize=15)
    ax.set(xlabel='实测β',ylabel='模型拟合β',xlim=(30,320),ylim=(30,320));fig.savefig(assets/'beta_actual_fitted.png');plt.close(fig)
    ordered=d.sort_values('PRESS_share',ascending=False).head(8);fig,ax=plt.subplots(figsize=(6.2,4.5),layout='constrained');colors=['#'+TEAL if k<4 else '#b7c8ce' for k in range(len(ordered))]
    ax.bar(np.arange(len(ordered)),ordered.PRESS_share,color=colors,width=.65);ax.set_xticks(np.arange(len(ordered)),[str(int(v)) for v in ordered.Run]);ax.set(xlabel='Run运行号',ylabel='留一预测误差平方和占比 / %',ylim=(0,21));ax.grid(axis='y',alpha=.18)
    for j,v in enumerate(ordered.PRESS_share):ax.text(j,v+.45,f'{v:.1f}',ha='center',fontsize=12)
    fig.savefig(assets/'beta_press.png');plt.close(fig)
    # Delegated figure already numerically cross-checked against these models.
    shutil.copy2(args.energy_plot,assets/'energy_candidates.png')
    prs=Presentation();prs.slide_width=Inches(13.333333);prs.slide_height=Inches(7.5);blank=prs.slide_layouts[6]
    notes=[]
    def rect(sl,x,y,w,h,color,line=None,radius=False):
        sh=sl.shapes.add_shape(MSO_SHAPE.ROUNDED_RECTANGLE if radius else MSO_SHAPE.RECTANGLE,Inches(x),Inches(y),Inches(w),Inches(h));sh.fill.solid();sh.fill.fore_color.rgb=rgb(color)
        if line:sh.line.color.rgb=rgb(line)
        else:sh.line.fill.background()
        if radius:
            try:sh.adjustments[0]=.10
            except Exception:pass
        return sh
    def text(sl,x,y,w,h,value,size=22,color=NAVY,bold=False,align=PP_ALIGN.LEFT):
        sh=sl.shapes.add_textbox(Inches(x),Inches(y),Inches(w),Inches(h));tf=sh.text_frame;tf.clear();tf.word_wrap=True
        tf.margin_left=0;tf.margin_right=0;tf.margin_top=0;tf.margin_bottom=0
        for j,line in enumerate(str(value).split('\n')):
            p=tf.paragraphs[0] if j==0 else tf.add_paragraph();p.text=line;p.alignment=align;p.space_after=Pt(6);p.line_spacing=1.15
            for run in p.runs:run.font.name=FONT;run.font.size=Pt(size);run.font.bold=bold;run.font.color.rgb=rgb(color)
        return sh
    def image(sl,path,x,y,w,h):
        from PIL import Image
        with Image.open(path) as im:iw,ih=im.size
        scale=min(w/iw,h/ih);nw,nh=iw*scale,ih*scale
        return sl.shapes.add_picture(str(path),Inches(x+(w-nw)/2),Inches(y+(h-nh)/2),width=Inches(nw),height=Inches(nh))
    def slide(title,section,note,backup=False):
        sl=prs.slides.add_slide(blank);sl.background.fill.solid();sl.background.fill.fore_color.rgb=rgb(BG)
        rect(sl,.55,.43,.10,.32,TEAL);text(sl,.8,.42,11,.3,section,12,GRAY)
        text(sl,.55,.91,12.2,.72,title,28,bold=True)
        rect(sl,.55,7.04,12.2,.012,'D5E1E6');text(sl,.55,7.14,11.4,.2,'数据：用户核实更正截图｜17次实验 / 13工况｜模型预测仍需独立验证',10,GRAY)
        text(sl,12,7.11,.7,.25,('备份 ' if backup else '')+str(len(prs.slides)),10,GRAY,align=PP_ALIGN.RIGHT)
        sl.notes_slide.notes_text_frame.text=note;notes.append((len(prs.slides),title,note));return sl
    def card(sl,x,y,w,h,label,value,detail='',accent=TEAL):
        rect(sl,x,y,w,h,WHITE,radius=True);rect(sl,x,y,.055,h,accent);text(sl,x+.2,y+.16,w-.4,.5,label,18,GRAY)
        text(sl,x+.2,y+.76,w-.4,.8,value,35,accent,True)
        if detail:text(sl,x+.2,y+1.60,w-.4,h-1.7,detail,17,NAVY)
    def table(sl,x,y,w,h,headers,rows,widths=None,font=18):
        shape=sl.shapes.add_table(len(rows)+1,len(headers),Inches(x),Inches(y),Inches(w),Inches(h));tab=shape.table
        if widths:
            for col,ww in zip(tab.columns,widths):col.width=Inches(ww)
        for i,row in enumerate([headers]+rows):
            for j,v in enumerate(row):
                cell=tab.cell(i,j);cell.text=str(v);cell.margin_left=Inches(.12);cell.margin_right=Inches(.08);cell.margin_top=Inches(.025 if font<=12 else .10);cell.margin_bottom=Inches(.025 if font<=12 else .06);cell.vertical_anchor=MSO_ANCHOR.MIDDLE
                cell.fill.solid();cell.fill.fore_color.rgb=rgb(NAVY if i==0 else (WHITE if i%2 else LIGHT))
                for p in cell.text_frame.paragraphs:
                    p.space_before=Pt(0);p.space_after=Pt(0);p.line_spacing=1.0
                    for run in p.runs:run.font.name=FONT;run.font.size=Pt(font);run.font.bold=(i==0);run.font.color.rgb=rgb(WHITE if i==0 else NAVY)
        for row in tab.rows:row.height=Inches(h/(len(rows)+1))
        return shape
    # Cover: no invented experimental system/author/institution.
    sl=prs.slides.add_slide(blank);sl.background.fill.solid();sl.background.fill.fore_color.rgb=rgb(NAVY);rect(sl,.7,.8,.12,.6,TEAL)
    text(sl,1,.83,10,.4,'阶段汇报｜三因素 Box–Behnken 设计',18,'AEC6D1');text(sl,1,2.0,11.4,1.75,'氟选择性萃取的响应面分析\n与低温方案筛选',36,WHITE,True)
    text(sl,1,4.3,10.9,.9,'提高氟回收 · 控制磷损失 · 以实测能耗完成最终评价',23,'D7E7ED')
    text(sl,1,6.15,9,.5,'正式更正数据｜17次实验｜2026年10月29日',16,'AEC6D1')
    note='建议用时30秒。说明这是阶段性数据分析，不是已经完成工艺最优与能耗验证。数据源为用户确认的复测或核实更正后的截图，运行8、9、15、17有实质更新。未获得更正后的完整精度原始浓度/体积工作簿。'
    sl.notes_slide.notes_text_frame.text=note;notes.append((1,'封面',note))
    sl=slide('先明确达标条件，再比较选择性与能耗','01 / 研究目标','建议45秒。F与P为截图萃取率；本汇报把P萃取作为磷损失指标。β为两分配系数之比，无量纲。按现有两相质量平衡口径，β=[F/(100−F)]/[P/(100−P)]。能耗暂无实测，以温度筛选低温候选，不给节能百分比或最低kWh结论。')
    card(sl,.65,1.95,3.85,3.0,'氟萃取率','≥ 80%','保证有效氟回收')
    card(sl,4.74,1.95,3.85,3.0,'磷损失','≤ 5%','减少磷进入萃取相',ORANGE)
    card(sl,8.83,1.95,3.85,3.0,'氟选择性 β','越高越好','β = D氟 / D磷\n需要同时满足回收指标')
    rect(sl,.65,5.35,12.03,.95,LIGHT,radius=True);text(sl,.88,5.55,11.5,.55,'能耗评价：后续比较 kWh/m³进料 与 kWh/kg回收氟；目前先筛低温方案。',20)
    sl=slide('17次实验包含13个工况，中心点重复5次','02 / 实验设计','建议50秒。A温度75/85/95°C；B相比0.667/1/1.333；C初始氟0.8/1/1.2%。12个边中点与5次中心重复合计17次，独立工况13个。相比方向应在正式汇报前按实验记录补全。图用编码水平表示，不是额外实验。')
    table(sl,.65,2.0,6.0,2.35,['因素','低','中心','高'],[['A 温度 / °C','75','85','95'],['B 相比','0.667','1.000','1.333'],['C 初始氟 / %','0.8','1.0','1.2']],widths=[2.7,1.1,1.1,1.1],font=19)
    text(sl,.72,4.8,5.75,1.4,'12个边中点 + 5次中心重复\n更正数据：Run8、9、15、17\n相比方向须按实验记录补全。',20)
    image(sl,assets/'design.png',6.8,1.8,5.9,4.9)
    sl=slide('单次达标不等于该工况稳定达标','03 / 实测结果','建议70秒。图的绿色区域为F≥80且P≤5。17次中只有Run3、11、17同时满足，三者均是同一中心工况的重复。中心5次F均值85.22022%，P均值5.066934%，P样本SD0.48414个百分点；P均值95%CI约4.46580–5.66807%。3/5单次通过不等于工况稳定通过。Run12虽β301.273，但F78.9055%低于80。')
    image(sl,assets/'observed_tradeoff.png',.58,1.82,7.6,4.7);image(sl,assets/'centre_repeats.png',8.25,1.82,4.5,4.7)
    text(sl,.75,6.45,12,.4,'中心工况：F均值85.22%，P均值5.067%；仅3/5次同时达标，仍需确认重复性。',19,ORANGE,True)
    sl=slide('氟模型内部预测较好，β模型仍存在失拟','04 / 模型可信度','建议65秒。全部基于最新正式更正截图。F完整二次：R²=.9950279、adj=.9886352、pred=.9700546、LOF p=.6502965。P线性预测优于完整二次。β完整二次虽整体p=.0094显著，但失拟p=.01143、预测R²=-.51278，不用于可靠寻优。预测R²为留一内部验证，不是新增实验验证。调整/预测差0.2是经验参考线。')
    rows=[['氟：完整二次','0.9950','0.9886','0.9701','0.6503'],['磷：线性','0.9209','0.9027','0.8536','0.0956'],['磷：完整二次','0.9633','0.9161','0.5255','0.0788'],['β：完整二次','0.8982','0.7673','−0.5128','0.0114']]
    table(sl,.65,1.98,12.0,3.0,['响应 / 模型','R²','调整R²','预测R²','失拟p'],rows,[4.0,1.8,2.1,2.1,2.0],font=20)
    text(sl,.8,5.36,11.8,1.0,'氟保留完整二次；磷优先采用线性。\nβ暂用于实测描述和诊断，先补充复验，再判断模型形式。',23,TEAL,True)
    sl=slide('用等高线识别达标区域，比只看曲面更直接','05 / 响应面与条件筛选','建议60秒。固定初始氟1%。左图是F模型均值曲面，右图F着色、白线F=80、橙线P=5；斜线区域仅是两模型点预测同时达标区域，不是已验证工况，也未考虑单次波动。星号A为75/.830/1%，B为90/.770/1%。范围处于原BBD设计点凸包内。')
    image(sl,assets/'F_surface.png',.55,1.88,5.95,4.55);image(sl,assets/'feasible_contour.png',6.64,1.88,6.15,4.55)
    text(sl,.75,6.46,12,.37,'固定初始氟1%｜白线：F=80%｜橙线：P=5%｜斜线区：点预测同时达标，尚待验证',17,GRAY)
    sl=slide('β的高影响条件需要复验，不能仅凭高值寻优','06 / 氟选择性诊断','建议75秒。β模型当前R²=.8982，预测R²=-.5128，LOF p=.0114。Run6、8各贡献17.20%PRESS，Run10、12各14.34%，合计63.08%。它们是高影响点，不是已确认错误；Bonferroni检验没有显著错误点。首轮Run6/8/12分别为85/1.333/1.2%，85/.667/.8%，95/.667/1%。Run12P1.22636%，0.1个百分点P偏差可使β约变8.3%。')
    image(sl,assets/'beta_actual_fitted.png',.6,1.82,6.0,3.9);image(sl,assets/'beta_press.png',6.75,1.82,6.0,3.9)
    text(sl,.78,5.95,11.9,.85,'首轮复验 Run6、8、12；预算允许再加10、1。\nRun12：β≈301，但F仅78.91%；高选择性仍需满足回收率门槛。',21,ORANGE,True)
    sl=slide('75°C可探索低温，90°C可作更保守的验证对照','07 / 能耗与候选方案','建议75秒。A75°C/.830/初始F1%，F均值80.9848、P3.9923；F单次PI79.8164–82.1532，P1.9574–6.0272，存在越界风险。B90°C/.770/1%，F81.2057、P2.92148，F PI80.1125–82.2989，P PI.9431–4.89984，当前模型界内但不是质量保证。无实测kWh。相比不同也改变热负荷，须实测同一处理量的能耗。')
    image(sl,assets/'energy_candidates.png',.62,1.78,12.08,4.5)
    text(sl,.8,6.34,11.8,.5,'两方案初始氟均1%｜A：75°C / 相比0.830｜B：90°C / 相比0.770｜尚无实测能耗',18,ORANGE,True)
    sl=slide('下一轮把β诊断与达标验证分开安排','08 / 验证计划','建议60秒。β诊断优先Run6/8/12各新增3次独立全流程重复，保留原观测；这些工况都不同时达80/5，不是最终推荐工况。达标/低温验证为A/B各3次独立重复，并记录本批F/P和实际能耗。新试验可按批次穿插中心工况质控；中心5次不是5种工况。补回完整精度原始浓度、相体积和仪器记录。')
    rect(sl,.65,2.0,5.85,3.9,WHITE,radius=True);rect(sl,6.8,2.0,5.85,3.9,WHITE,radius=True)
    text(sl,.9,2.25,5.35,.5,'路线一｜β模型诊断',25,TEAL,True)
    text(sl,.9,3.0,5.25,2.4,'Run6、8、12：各新增3次独立萃取\n\n测F/P浓度与前后相体积\n保留旧数据和全部复测结果\n用于区分重复性问题与模型失拟',20)
    text(sl,7.05,2.25,5.35,.5,'路线二｜达标与低温验证',25,TEAL,True)
    text(sl,7.05,3.0,5.25,2.4,'A/B方案：各3次独立重复\n\n同步测本批F/P和总耗电\n统一处理量、时间和计量范围\n比较kWh/m³与kWh/kg回收氟',20)
    text(sl,.8,6.25,11.8,.55,'复验目的不同：高影响点用于诊断；低温候选用于确认达标与实际能耗。',20,GRAY)
    sl=slide('阶段结论：已有模型基础，尚需独立验证','09 / 结论','建议45秒。总结三点：一是F二次/P线性内部预测相对较好，但不能替代新增实验。二是β失拟显著、高β不保证回收/磷损失达标，按诊断优先级复验。三是75/90低温候选尚未独立验证，能源尚无数据，后续在达标基础上测量单位能耗。请勿宣称已得到稳定达标或最低能耗工况。')
    for y,num,title,detail in [(2.0,'01','模型基础','氟二次与磷线性具有较好的内部预测表现。'),(3.47,'02','选择性边界','β模型仍失拟；高β需要与回收率、磷损失一起判断。'),(4.94,'03','下一步证据','先做独立重复与能耗配对测量，再确定最终操作条件。')]:
        rect(sl,.7,y,11.95,1.15,WHITE,radius=True);text(sl,.95,y+.24,.9,.6,num,30,TEAL,True);text(sl,2,y+.15,2.2,.6,title,23,NAVY,True);text(sl,4.2,y+.22,8.0,.7,detail,21)
    # Backup pages: detailed data, cubic caveat, equations/statistic definitions.
    sl=slide('备份｜17次正式更正数据与运行编号','备份 / 数据追溯','备用页。全部采用截图显示精度；Run是运行顺序，Std是标准设计序号。Run8/9/15/17为用户确认的正式更正。温度°C，初始氟%，β无量纲；P列按磷萃取率作为磷损失指标。相同中心工况不可当作独立不同条件。',True)
    rows=[[int(r.Std),int(r.Run),f'{r.Temperature:g}',f'{r.Ratio:.3f}',f'{r.Initial_F:.1f}',f'{r.F:.4f}',f'{r.P:.5f}',f'{r.beta:.3f}'] for _,r in d.iterrows()]
    table(sl,.7,1.82,11.95,4.88,['Std','Run','T/°C','相比','初始F/%','F/%','P/%','β'],rows,[1.0,1.0,1.2,1.4,1.5,1.9,1.95,2.0],font=11)
    sl=slide('备份｜β三次模型的高R²与NA预测指标','备份 / 模型可估计性','备用页。此处以β响应为例。当前BBD有13个独立工况；20列完整三次设计矩阵秩13，与独立工况数相同，12个非中心点杠杆值1；残差只剩中心纯误差。β三次R²=.99194245、adj=.96776979，不能计算通常PRESS和预测R²。某些显示零的三次系数可能源于混杂/不可估计，不能据此说效应为零。三次模型需要新独立设计条件和可估计性检查。',True)
    card(sl,.7,2.0,3.8,2.8,'独立工况','13','17次运行，中心重复5次')
    card(sl,4.78,2.0,3.8,2.8,'三次设计有效秩','13','12个非中心点杠杆值=1',ORANGE)
    card(sl,8.86,2.0,3.8,2.8,'预测R²','NA','PRESS无法按常规留一法计算',ORANGE)
    text(sl,.9,5.3,11.5,1.0,'β三次模型R²≈0.9919，现有点被拟合得很满。\n当前三次模型不作为可靠预测或工艺寻优的最终模型。',24,NAVY,True)
    sl=slide('备份｜编码方程与指标口径','备份 / 计算方法','备用页。A=(T−85)/10，B=(相比−1)/.333，C=(初始F−1)/.2，初始F的数字1表示1%。R²=1−SSE/SST；预测R²=1−PRESS/SST，PRESS按留一重拟合核验。F/P模型下的候选区间是各响应分别的固定模型区间，不计寻优/选模等不确定性。β公式按现有两相质量平衡口径。计算使用Python标准OLS复核，并非运行专有软件自动生成原生项目。',True)
    text(sl,.8,1.92,11.8,.65,'A=(T−85)/10；B=(相比−1)/0.333；C=(初始氟−1)/0.2',22,TEAL,True)
    text(sl,.8,2.85,11.7,1.2,'氟萃取率 = 85.22022 + 0.86809A + 5.09481B − 0.13930C\n− 0.07145AB + 0.89008AC + 1.36763BC\n− 0.24156A² − 1.87381B² − 0.46909C²',20)
    text(sl,.8,4.42,11.8,.65,'磷萃取率 = 5.60440 − 0.27084A + 3.68835B − 0.35034C',21)
    text(sl,.8,5.47,11.8,.9,'R²：已有数据拟合程度；预测R²：留一内部预测指标。\n区间、独立重复及实际工艺约束，需要共同用于判断。',21,GRAY)
    # Remove an incidental draft wording from speaker notes, retaining the scientific point.
    for sl in prs.slides:
        tf=sl.notes_slide.notes_text_frame
        if '两者? 应说' in tf.text:tf.text=tf.text.replace('两者? 应说','')
    deck=out/'response_surface_group_meeting.pptx';prs.save(deck)
    notes_path=out/'speaker_notes.md';notes_path.write_text('# 组会汇报讲稿提示\n\n按8–10分钟准备；正文10页，备份3页。\n\n'+'\n\n'.join(f'## 第{i}页：{title}\n\n{note.replace("两者? 应说","")}' for i,title,note in notes),encoding='utf-8')
    shutil.copy2(args.data,out/'source_data.csv');shutil.copy2(__file__,out/'build_presentation.py')
    pd.DataFrame({'slide':list(range(1,len(prs.slides)+1)),'title':[v[1] for v in notes],'speaker_notes':[v[2].replace('两者? 应说','') for v in notes]}).to_csv(out/'slide_outline.csv',index=False,encoding='utf-8-sig')
    passed=d[(d.F>=80)&(d.P<=5)]
    assert passed.Run.tolist()==[3,11,17]
    assert len(prs.slides)==13 and np.isclose(centre.P.mean(),5.066934)
    checked=Presentation(deck);assert len(checked.slides)==13 and all(sl.has_notes_slide for sl in checked.slides)
    print('PPT',deck,'slides',len(checked.slides),'passed_runs',passed.Run.tolist(),'top4_PRESS_share',float(np.sort(share)[-4:].sum()))

if __name__=='__main__':main()
